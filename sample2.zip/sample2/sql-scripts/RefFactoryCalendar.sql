CREATE	TABLE	RefFactoryCalendar(
    CalendarID	char(2) NOT NULL,
    PeriodDate	date NOT NULL,
    WorkingDayIndc   char(1) DEFAULT NULL,
    Year   int(11) DEFAULT NULL,
    DayNoinWeek   int(11) DEFAULT NULL,
    DayNoinMonth   int(11) DEFAULT NULL,
    DayNoinYear   int(11) DEFAULT NULL,
    WeekNoinMonth   int(11) DEFAULT NULL,
    WeekNoinYear   int(11) DEFAULT NULL,
    MonthNoinYear   int(11) DEFAULT NULL,
    MonthFullName   char(9) DEFAULT NULL,
  PRIMARY KEY (  CalendarID  ,  PeriodDate  )
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

