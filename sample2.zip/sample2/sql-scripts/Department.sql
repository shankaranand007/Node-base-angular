CREATE	TABLE	Department(
    DepartmentCode	char(4) NOT NULL,
    DepartmentName	varchar(25) DEFAULT NULL,
    CreatedOn		datetime DEFAULT NULL,
    CreatedBy		varchar(12) DEFAULT NULL,
    UpdatedOn		datetime DEFAULT NULL,
    UpdatedBy		varchar(12) DEFAULT NULL,
  PRIMARY KEY (DepartmentCode)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

