CREATE	TABLE   RefPlant(
    PlantID   	char(4) NOT NULL,
    PlantName   varchar(30) DEFAULT NULL,
    SiteName   	varchar(30) DEFAULT NULL,
    PlantType   char(1) DEFAULT NULL,
    CalendarID  char(2) DEFAULT NULL,
    Region   	char(3) DEFAULT NULL,
    BusinessUnit   char(4) DEFAULT NULL,
    Country   	char(3) DEFAULT NULL,
    City   		varchar(25) DEFAULT NULL,
  PRIMARY KEY (PlantID)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

