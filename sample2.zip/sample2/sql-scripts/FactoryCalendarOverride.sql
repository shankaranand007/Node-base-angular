CREATE TABLE   FactoryCalendarOverride   (
    PlantID   char(4) NOT NULL,
    OverrideDate   date NOT NULL,
    DepartmentCode   char(4) DEFAULT NULL,
    DayIndicator   int(11) DEFAULT NULL,
    IsActive   char(1) DEFAULT NULL,
    CreatedOn   datetime DEFAULT NULL,
    CreatedBy   varchar(12) DEFAULT NULL,
    UpdatedOn   datetime DEFAULT NULL,
    UpdatedBy   varchar(12) DEFAULT NULL,
  PRIMARY KEY (  PlantID  ,  OverrideDate  )
) ENGINE=InnoDB DEFAULT CHARSET=latin1;