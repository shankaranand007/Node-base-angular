# Development Configuration Steps For oFlow API

### Pre-requisites
- Node Js 6.10 LTS Version [Download Link](https://nodejs.org/en/download/)
- Yarn Package Manager [Download Link](https://yarnpkg.com/en/docs/install)



> It's a one time activity for setting up node environment. 
> The above steps are required only if you haven't configured Node Js 

### Installation
 Install the dependencies and devDependencies and start dev server


```sh
yarn install
npm run start
```
### Release Build

```sh
npm run prod
```


Chnage log location to folder path from app.config.json
Include JOI for validation
Usage Analytics

