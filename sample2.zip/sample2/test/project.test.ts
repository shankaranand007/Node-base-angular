import * as mocha from 'mocha';
import * as chai from 'chai';
import chaiHttp = require('chai-http');
import { app } from './../src/main';

let route = '/project';
let project;
chai.use(chaiHttp);
const expect = chai.expect;

function getProjectId() {
    return project ? project.ProjectId : 0;
}

it('Invalid routing', () => {
    return chai.request(app).get(route + '/unknownrouting')

        .then(res => {
        }).catch((err) => {
            expect(err.status).to.equal(404);
        });
});

it('Returns the projects ', () => {
    return chai.request(app).get(route)
        .then(res => {
            project = res.body[0];
            expect(res.status).to.equal(200);
            expect(res).to.be.json;
            expect(res.body).to.be.an('array');
        });
});

