
import { WebApi } from './webApi';
import { IConfig, AppSetting } from './config';
import { SequelizeConfig, sequelize } from './helpers/sequelize';

let api = new WebApi();
let config: IConfig = AppSetting.getConfig();

// sql.setDefaultConfig(config.GetSQLConnectionString());
api.run();
console.log(`listening on ${config.Port}`);
sequelize.setConnection();
let app = new WebApi().app;
export { app };
