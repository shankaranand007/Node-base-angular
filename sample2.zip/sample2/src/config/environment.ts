export enum Environment {
    BusDev, Dev, Local, Testing, Qas, Prod, QaStage
};
