import { Router, Request, Response, NextFunction } from 'express';
import { Api, Utilities } from './../helpers';
import { UserServiceManager } from '../data-manager/userservice.manager';
import { IUsers } from '../entities';
import { AppSetting } from '../config';
import * as request from 'request';


export class UserController {
    public static route = '/users';
    public router: Router = Router();

    constructor() {
        this.router.get('/', this.getUserInfo);
        this.router.get('/:userId/photo', this.getUserPhoto);
        this.router.put('/lastlogin', this.updateLastLogin);
        this.router.get('/searchusersbyname/:name?', this.getSearchUser);
    }

    public getUserInfo(req: Request, res: Response, next: NextFunction) {
        let email = req.query['emailIds'];
        new UserServiceManager().getUser(email).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getUserPhoto(req: Request, res: Response, next: NextFunction) {
        let cnfg = AppSetting.getConfig();
        const config = cnfg.MDR['user'];
        request(config.url + req.params['userId'] + '/photo')
            .on('error', (err) => { next(err); })
            .pipe(res);
    }

    public getSearchUser(req: Request, res: Response, next: NextFunction) {
        let name = req.params['name'];
        new UserServiceManager().getSearchUser(name).then((result) => {

            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public updateLastLogin(req: Request, res: Response, next: NextFunction) {
        let user: IUsers = req.body;

        const userId = Utilities.getCurrentUser(req, res);
        user.UpdatedBy = userId;
        new UserServiceManager().updateLastLogin(user).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }
}
