import { Router, Request, Response, NextFunction } from 'express';
import { Api, Utilities } from './../helpers';
import { ProfilesServiceManager } from '../data-manager/profiles.manager';
import { IProfile } from '../entities/IProfile';
import { IUsers } from '../entities/IUsers';

export class ProfilesController {

    public static route = '/profile';
    public router: Router = Router();

    constructor() {
        this.router.post('/', this.CreateProfile);
        this.router.put('/', this.UpdateProfile);
        this.router.put('/updatestatus', this.UpdateStatus);
        this.router.put('/setdefaultprofile', this.SetDefaultProfile);
        this.router.get('/:userID/userprofiles', this.UserProfiles);
        this.router.get('/:userID/defaultprofiles', this.getDefaultProfile);
        this.router.get('/global', this.GetGlobalProfiles);
        this.router.post('/user', this.createUser);
        this.router.get('/user/all', this.getOflowUsers);
        this.router.put('/user/:userID', this.updateUserAdminAccess);
        this.router.get('/user/:userID?', this.GetUserProfile);
        this.router.delete('/:profileID', this.DeleteProfile);
    }

    public getOflowUsers(req: Request, res: Response, next: NextFunction) {
        new ProfilesServiceManager().getAllOflowUsers().then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public updateUserAdminAccess(req: Request, res: Response, next: NextFunction) {
        const user: IUsers = req.body;
        user.UpdatedBy = Utilities.getCurrentUser(req, res);
        user.UpdatedOn = new Date();
        new ProfilesServiceManager().updateUserAdminAccess(user).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public async CreateProfile(req: Request, res: Response, next: NextFunction) {
        const profile: IProfile = req.body;

        try {
            profile.CreatedBy = Utilities.getCurrentUser(req, res);
            const result = await new ProfilesServiceManager().createProfile(profile);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public async UpdateProfile(req: Request, res: Response, next: NextFunction) {
        const profile: IProfile = req.body;

        try {
            profile.UpdatedBy = Utilities.getCurrentUser(req, res);
            const result = await new ProfilesServiceManager().updateProfile(profile);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public async GetGlobalProfiles(req: Request, res: Response, next: NextFunction) {
        try {
            const result = await new ProfilesServiceManager().getGlobalProfiles();
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public async GetUserProfile(req: Request, res: Response, next: NextFunction) {
        const userId = req.params['userID'];

        try {
            const result = await new ProfilesServiceManager().getUserProfile(userId);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public UserProfiles(req: Request, res: Response, next: NextFunction) {
        const userId = req.params['userID'];

        new ProfilesServiceManager().userProfiles(userId).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public UpdateStatus(req: Request, res: Response, next: NextFunction) {
        const updateInfo: IProfile = req.body;

        updateInfo.UpdatedBy = Utilities.getCurrentUser(req, res);
        new ProfilesServiceManager().updateStatus(updateInfo).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public async getDefaultProfile(req: Request, res: Response, next: NextFunction) {
        const userId = req.params['userID'];

        try {
            const result = await new ProfilesServiceManager().getDefaultProfile(userId);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public SetDefaultProfile(req: Request, res: Response, next: NextFunction) {
        const user: IUsers = req.body;

        user.ID = Utilities.getCurrentUser(req, res);
        user.UpdatedBy = Utilities.getCurrentUser(req, res);
        new ProfilesServiceManager().setDefaultProfile(user).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public DeleteProfile(req: Request, res: Response, next: NextFunction) {
        const profileID = req.params['profileID'];
        const updatedBy = Utilities.getCurrentUser(req, res);

        new ProfilesServiceManager().deleteProfile(profileID, updatedBy).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public async createUser(req: Request, res: Response, next: NextFunction) {
        let user: IUsers = req.body;
        const userId = Utilities.getCurrentUser(req, res);

        try {
            user.ID = userId; user.CreatedBy = userId;
            const result = await new ProfilesServiceManager().createUser(user);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }
}
