import { Router, Request, Response, NextFunction } from 'express';
import { Api } from './../helpers';
import { IConfig } from '../config/IConfig';
import { AppSetting } from '../config';
import { ConfigManager } from '../config/config.manager';

export class InfoController {
    public static route = '/info';
    public router: Router = Router();
    constructor() {
        this.router.get('/', this.getInfo);
        this.router.get('/reset', this.reset);
    }
    public getInfo(request: Request, response: Response, next: NextFunction) {
        let config: IConfig = AppSetting.getConfig();
        let info = {
            name: config.AppConfig.name,
            version: config.AppConfig.version,
            DatabaseServer: config.DBConnections['default'].server,
            Database: config.DBConnections['default'].database,
            DatabaseTimeout: config.DBConnections['default'].requestTimeout,
            MdrUser: config.MDR['user'].url
        };
        return Api.ok(request, response, info);
    }

    public reset(request: Request, response: Response, next: NextFunction) {
        let configManager = new ConfigManager();
        configManager.reset();
        return Api.ok(request, response, 'config reset successful');
    }
}
