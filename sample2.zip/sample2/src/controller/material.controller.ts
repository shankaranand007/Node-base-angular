import { Router, Request, Response, NextFunction } from 'express';
import { Api, Utilities } from './../helpers';
import { MaterialServiceManager } from '../data-manager/material.manager';
import { IMaterialSubstitution } from '../entities';

export class MaterialController {

    public static route = '/materials';
    public router: Router = Router();

    constructor() {
        this.router.get('/', this.getSubstitution);
        this.router.get('/code/:plantid/:materialcode', this.getMaterialCode);
        this.router.post('/', this.createSubstitution);
        this.router.put('/', this.updateSubstitution);
        this.router.delete('/substitution/:plantid/:materialfrom/:materialto', this.deleteSubstitution);
        this.router.get('/peaks/:plantid/:materialcode', this.getMaterialPeaks);

    }

    public getSubstitution(req: Request, res: Response, next: NextFunction) {
        new MaterialServiceManager().getSubstitution().then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getMaterialCode(req: Request, res: Response, next: NextFunction) {
        const plantId = req.params['plantid'];
        const materialCode = req.params['materialcode'];
        new MaterialServiceManager().getMaterialCode(plantId, materialCode).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public async updateSubstitution(req: Request, res: Response, next: NextFunction) {
        let materialSubstitution: IMaterialSubstitution = req.body;
        try {
            materialSubstitution.UpdatedBy = Utilities.getCurrentUser(req, res);
            materialSubstitution.UpdatedOn = new Date();
            const result = await new MaterialServiceManager().updateSubstitution(materialSubstitution);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }


    public async createSubstitution(req: Request, res: Response, next: NextFunction) {
        let substitution: IMaterialSubstitution = req.body;
        const userId = Utilities.getCurrentUser(req, res);

        try {
            substitution.CreatedBy = userId;
            substitution.CreatedOn = new Date();
            const result = await new MaterialServiceManager().createSubstitution(substitution);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error.original);
        };
    }

    public deleteSubstitution(req: Request, res: Response, next: NextFunction) {
        const plant = req.params['plantid'];
        const materialFrom = req.params['materialfrom'];
        const materialTo = req.params['materialto'];
        const updatedBy = Utilities.getCurrentUser(req, res);
        new MaterialServiceManager().deleteSubstitution(plant, materialFrom, materialTo, updatedBy).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }
    public getMaterialPeaks(req: Request, res: Response, next: NextFunction) {
        const plantId = req.params['plantid'];
        const materialCode = req.params['materialcode'];
        new MaterialServiceManager().getMaterialPeaks(plantId, materialCode).then((result) => {
            console.log(result);
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }
}
