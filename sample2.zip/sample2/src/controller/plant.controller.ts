import { Router, Request, Response, NextFunction } from 'express';
import { Api } from './../helpers';
import { PlantServiceManager } from '../data-manager/plantservice.manager';
import { IPlant } from '../entities';

export class PlantController {

    public static route = '/plant';
    public router: Router = Router();

    constructor() {
        this.router.get('/', this.getPlants);
        this.router.get('/department', this.getDepartments);
        this.router.get('/:id', this.getPlantInfo);
        this.router.get('/department/:id', this.getDepartment);
        this.router.post('/mrps', this.getMrps);
        this.router.post('/sitegroup', this.getSiteGroup);
    }

    public getPlants(req: Request, res: Response, next: NextFunction) {
        new PlantServiceManager().getPlants().then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getPlantInfo(req: Request, res: Response, next: NextFunction) {
        const plantId = req.params['id'];

        new PlantServiceManager().getPlantInfo(plantId).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getDepartments(req: Request, res: Response, next: NextFunction) {
        new PlantServiceManager().getDepartments().then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getDepartment(req: Request, res: Response, next: NextFunction) {
        const departmentCode = req.params['id'];

        new PlantServiceManager().getDepartment(departmentCode).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getMrps(req: Request, res: Response, next: NextFunction) {
        const plants: any = req.body;

        new PlantServiceManager().getMrps(plants).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getSiteGroup(req: Request, res: Response, next: NextFunction) {
        const plants: any = req.body;

        new PlantServiceManager().getSiteGroup(plants).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }
}
