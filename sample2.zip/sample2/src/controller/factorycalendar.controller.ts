import { Router, Request, Response, NextFunction } from 'express';
import { Api, Utilities } from './../helpers';
import { FactoryCalendarServiceManager } from '../data-manager/factorycalendar.manager';
import { IFactoryCalendarOverride } from '../entities/IFactoryCalendarOverride';

export class FactoryCalendarController {

    public static route = '/calendar';
    public router: Router = Router();

    constructor() {
        this.router.post('/', this.createCalendar);
        this.router.put('/', this.updateCalendar);
        this.router.get('/generatecalendar', this.generateFactoryCalendarRunningNumbers);
        this.router.get('/holiday/:plantId/:date', this.getHolidayStatus);
        this.router.get('/:calendarYear', this.getFactoryCalendar);
        this.router.get('/:plantId/:date', this.getCalendarForDate);
        this.router.delete('/:plantId/:date/:deptCode?', this.deleteCalendar);
    }

    public getHolidayStatus(req: Request, res: Response, next: NextFunction) {
        const plantId = req.params['plantId'];
        const date = req.params['date'];

        new FactoryCalendarServiceManager().getHolidayStatus(plantId, date).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getFactoryCalendar(req: Request, res: Response, next: NextFunction) {
        const calendarYear = req.params['calendarYear'];
        new FactoryCalendarServiceManager().getFactoryCalendar(calendarYear).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public getCalendarForDate(req: Request, res: Response, next: NextFunction) {
        const plantId = req.params['plantId'];
        const date = req.params['date'];

        new FactoryCalendarServiceManager().getCalendarForDate(plantId, date).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public async createCalendar(req: Request, res: Response, next: NextFunction) {
        const factoryCalendar: IFactoryCalendarOverride[] = req.body;

        try {
            const result = await new FactoryCalendarServiceManager().createCalendar(factoryCalendar);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public async updateCalendar(req: Request, res: Response, next: NextFunction) {
        const factoryCalendar: IFactoryCalendarOverride[] = req.body;

        try {
            const result = await new FactoryCalendarServiceManager().updateCalendar(factoryCalendar);
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }

    public deleteCalendar(req: Request, res: Response, next: NextFunction) {
        const plantId = req.params['plantId'];
        const date = req.params['date'];
        const deptCode = req.params['deptCode'];

        new FactoryCalendarServiceManager().deleteCalendar(plantId, date, deptCode).then((result) => {
            return Api.ok(req, res, result);
        }, (error) => {
            next(error);
        });
    }

    public generateFactoryCalendarRunningNumbers(req: Request, res: Response, next: NextFunction) {
        try {
            const result = new FactoryCalendarServiceManager().generateFactoryCalendarRunningNumbers(Utilities.getCurrentUser(req, res));
            return Api.ok(req, res, result);
        } catch (error) {
            next(error);
        };
    }
}
