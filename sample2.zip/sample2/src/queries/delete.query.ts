export const DeleteQuery = {
    deleteFactoryCalendarOverride: `UPDATE FactoryCalendarOverride set IsActive = 'N' WHERE PlantID = :plantID AND OverrideDate = :overrideDate AND DepartmentCode = :departmentCode;`,
    deleteFactoryCalendarOverrideAllDept: `UPDATE FactoryCalendarOverride set IsActive = 'N' WHERE PlantID = :plantID AND OverrideDate = :overrideDate;`,
    deleteProfileInfo: `UPDATE ProfileInfo SET Status = 'D', UpdatedBy = :UpdatedBy, UpdatedOn = :UpdatedOn WHERE ID = :ID;`,
    deleteMaterialSubstitution: `UPDATE MaterialSubstitution SET Status = 'D', UpdatedBy = :UpdatedBy, UpdatedOn = :UpdatedOn WHERE PlantID = :PlantID AND MaterialFrom= :MaterialFrom AND MaterialTo= :MaterialTo;`,
};
