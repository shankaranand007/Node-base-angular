export const InsertQuery = {
    insertFactoryCalendarOverride: 'INSERT INTO FactoryCalendarOverride (PlantID, OverrideDate, DepartmentCode, DayIndicator, IsActive, CreatedOn, CreatedBy) VALUES (:PlantID, :OverrideDate, :DepartmentCode, :DayIndicator, :IsActive, :CreatedOn, :CreatedBy)',
    insertProfiles: `INSERT INTO ProfileInfo (Name, Type, UserID, Status, Info, Region, CreatedOn, CreatedBy) VALUES (:name, :type, :userid, :status, :info, :region, :createdon, :createdby);`,
    insertUser: `INSERT INTO Users (ID, Name, DefaultProfileID, LastLogin, CreatedOn, CreatedBy) VALUES (:ID, :Name, :DefaultProfileID, NOW(), NOW(), :CreatedBy);`,
    insertFactoryCalendar: `INSERT INTO FactoryCalendar (PlantID, CalendarDate, DepartmentCode, DayIndicator, FactoryDay, IsActive, CreatedOn, CreatedBy) VALUES (:PlantID, :CalendarDate, :DepartmentCode, :DayIndicator, :FactoryDay, 'Y', NOW(), :CreatedBy);`,
    insertMaterialSubstitution: `INSERT INTO MaterialSubstitution (PlantID, SubType, MaterialFrom, MaterialTo, Status, CreatedOn, CreatedBy) VALUES (:PlantID, :SubType, :MaterialFrom, :MaterialTo, :Status, :CreatedOn, :CreatedBy);`
};
