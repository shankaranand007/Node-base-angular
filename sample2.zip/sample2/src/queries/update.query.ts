export const UpdateQuery = {
    updateCalendar: `UPDATE FactoryCalendarOverride set DayIndicator = :DayIndicator, UpdatedOn = :UpdatedOn, UpdatedBy = :UpdatedBy, IsActive = :IsActive WHERE PlantID = :PlantID AND OverrideDate = :OverrideDate AND DepartmentCode = :DepartmentCode;`,
    updateProfile: `UPDATE ProfileInfo SET Name = :name, Status = :status, Info = :info, UpdatedOn = :updatedon, UpdatedBy = :updateby WHERE ID = :id`,
    updateProfileStatus: `UPDATE ProfileInfo SET Status = :Status, UpdatedBy = :UpdatedBy, UpdatedOn = :UpdatedOn WHERE ID = :ID;`,
    updateUserDefaultProfile: `UPDATE Users SET DefaultProfileID = :DefaultProfileID, UpdatedBy = :UpdatedBy, UpdatedOn = :UpdatedOn WHERE ID = :ID;`,
    updateLastLogin: `UPDATE Users SET LastLogin = :LastLogin WHERE ID = :ID;`,
    updateUserAdminAccess: `UPDATE Users SET IsAdmin = :IsAdmin, UpdatedBy = :UpdatedBy, UpdatedOn = :UpdatedOn WHERE ID = :ID;`,
    updateFactoryCalendarRunValue: `UPDATE FactoryCalendar SET DayIndicator = :DayIndicator, FactoryDay = :FactoryDay WHERE PlantID = :PlantID AND CalendarDate = :CalendarDate AND DepartmentCode = :DepartmentCode;`,
    updateSubstitution: `UPDATE MaterialSubstitution SET SubType=:SubType, MaterialFrom=:MaterialFrom, MaterialTo=:MaterialTo, Status=:Status, UpdatedBy=:UpdatedBy, UpdatedOn=:UpdatedOn WHERE Plant=:Plant and MaterialFrom=:MaterialFrom and MaterialTo=:MaterialTo;`,
};
