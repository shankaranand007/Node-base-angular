import { Request } from 'express';
import { map, mapKeys, camelCase, groupBy, trim, each, lowerCase } from 'lodash';

export class QueryParser {
    private static getFilters(filter: string): { operation: string; column: string; value: string; } {
        if (filter) {
            let operation = filter.substring(0, filter.lastIndexOf("("));
            let column = filter.substring(filter.lastIndexOf("(") + 1, filter.lastIndexOf(","));
            column = column.toLowerCase();
            let value = filter.substring(filter.indexOf("'") + 1, filter.lastIndexOf("'"));
            if (!value) {
                value = filter.substring(filter.indexOf(",") + 1, filter.lastIndexOf(")"));
            }
            return {
                operation, column, value
            };
        }
    };

    static getFilterQuery(_filter: string, ColumnsForFiter: { [id: string]: string; }): string {
        let condition = "1=1";
        if (_filter) {
            let filter = this.getFilters(_filter);
            filter.column = ColumnsForFiter[filter.column] ? `${ColumnsForFiter[filter.column]}.${filter.column}` : filter.column;
            switch (filter.operation) {
                case "contains":
                    condition = `${filter.column} like '%${filter.value}%'`;
                    break;
                case "startswith":
                    condition = `${filter.column} like '${filter.value}%'`;
                    break;
                case "endswith":
                    condition = `${filter.column} like '%${filter.value}'`;
                    break;
                default:
                    condition = `1=2`; // Should not return anything when incorrect filter passed
                    break;
            }
        }
        return condition;
    };

    static getSelectQuery(requset: Request, columnsForFiter: { [id: string]: string; }, selectColumns: string): string {
        if (requset.query.$select) {
            let columns = requset.query.$select.split(',');
            let found = columns.every(r => columnsForFiter[r]) >= 0;
            console.log(found);
        }
        return selectColumns;
    };

    static convertToBoolean(input: string): boolean {
        try {
            return JSON.parse(input);
        } catch (e) {
            return null;
        }
    }
}

