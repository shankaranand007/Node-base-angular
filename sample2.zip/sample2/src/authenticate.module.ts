import * as express from 'express';
import { AppSetting, IConfig, Environment } from './config';
import { find } from 'lodash';
import { Api } from './helpers/api';
const OktaJwtVerifier = require('@okta/jwt-verifier');
export class AuthenticationModule {

    public static isExcluded(req, res) {

        let config: IConfig = AppSetting.getConfig();

        let exclude = config.AppSettings['exclude'];
        let result = find(exclude, (s) => {
            return req.url.startsWith(s);
        });
        let ref = req.headers['referer'] ? req.headers['referer'] : '';
        let testing = AppSetting.Env === Environment.Testing || ref.indexOf('swagger') !== -1;
        return testing || result;

    }

    public static authenticate(app: express.Express) {
        app.use(function (req, res, next) {
            let config = AppSetting.getConfig();
            if (req.url === '/') {
                return res.json({
                    name: config.AppConfig.name,
                    version: config.AppConfig.version,
                });
            } else if (AuthenticationModule.isExcluded(req, res)) {
                req.headers['user'] = 'mxj1234';
                next();
            } else {
                let auth = req.headers['x-access-token'];
                if (!auth) {
                    return Api.unauthorized(req, res, 'Invalid Token');
                }
                AuthenticationModule.validateOkta(config, auth, req, res, next);
            }
        });

    }
    public static validateOkta(config, token, req, res, next) {
        const oktaJwtVerifier = new OktaJwtVerifier({
            issuer: config.OktaConfig.url
        });
        oktaJwtVerifier.verifyAccessToken(token)
            .then(jwt => {
                let userid = jwt.claims ? jwt.claims.preferred_username : null;
                let id = userid.split('@');
                userid = id ? id[0] : null;
                if (userid) {
                    req.headers['user'] = userid;
                    next();
                } else {
                    Api.unauthorized(req, res, 'Invalid userId');
                }

            })
            .catch(err => {
                console.log('error', err);
                Api.unauthorized(req, res, err);
            });
    }
}
