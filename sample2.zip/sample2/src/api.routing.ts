import * as express from 'express';
import { UserController } from './controller/user.controller';
import { InfoController } from './controller/info.controller';
import { PlantController } from './controller/plant.controller';
import { FactoryCalendarController } from './controller/factorycalendar.controller';
import { ProfilesController } from './controller/profiles.controller';
import { MaterialController } from './controller/material.controller';

export class ApiRouting {

    public static ConfigureRouters(app: express.Router) {
        app.use(UserController.route, new UserController().router);
        app.use(InfoController.route, new InfoController().router);
        app.use(PlantController.route, new PlantController().router);
        app.use(FactoryCalendarController.route, new FactoryCalendarController().router);
        app.use(ProfilesController.route, new ProfilesController().router);
        app.use(MaterialController.route, new MaterialController().router);
    }
}
