import { AppSetting, IConfig } from '../config';

const fs = require('fs');
const nodemailer = require('nodemailer');
const smtpTransport = require('nodemailer-smtp-transport');


export class MailManager {
    public static sendMail(subject, to, data, cc?, attachments?) {
        return new Promise((resolve, reject) => {
            let app: IConfig = AppSetting.getConfig();
            let transporter = nodemailer.createTransport(smtpTransport({
                host: app.SMTPHost
            }));

            transporter.sendMail({
                from: app.FromMail,
                to: to,
                cc: cc,
                subject: subject,
                html: data,
                attachments: attachments
            }, (error, info) => {
                transporter.close();
                if (error) {
                    reject(error);
                } else {
                    resolve(info);
                }
            });
        });
    }

    public static getMailContent(fileName: string) {
        return fs.readFileSync('./src/email-templates/' + fileName, 'utf8');
    }

}
