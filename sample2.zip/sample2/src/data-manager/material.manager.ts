import { SqlManager } from '../helpers/sequelize';
import { SelectQuery, InsertQuery, UpdateQuery, DeleteQuery } from '../queries';
import { IMaterialSubstitution } from '../entities';


export class MaterialServiceManager {

    public getSubstitution() {
        let db = new SqlManager();
        return db.Get(SelectQuery.getSubstitution, {});
    }

    public getMaterialCode(plantId: string, materialCode: string) {
        let db = new SqlManager();
        return db.Get(SelectQuery.getMaterialCode, { PlantID: plantId, MateriaNo: parseInt(materialCode, 10) });
    }

    public async createSubstitution(substitution: IMaterialSubstitution) {
        const db = new SqlManager();
        await db.InsertAsync(InsertQuery.insertMaterialSubstitution, substitution);
        return true;
    }

    public async updateSubstitution(materialSubstitution: IMaterialSubstitution) {
        const db = new SqlManager();
        await db.UpdateAsync(UpdateQuery.updateSubstitution, materialSubstitution);
        return true;
    }

    public deleteSubstitution(Plant: string, MaterialFrom: string, MaterialTo: string, requestUser: string) {
        const db = new SqlManager();
        let params = {
            PlantID: Plant,
            MaterialFrom: MaterialFrom,
            MaterialTo: MaterialTo,
            UpdatedBy: requestUser,
            UpdatedOn: new Date(),
        }
        return db.Delete(DeleteQuery.deleteMaterialSubstitution, params);
    }
    public getMaterialPeaks(plantId: string, materialCode: string) {
        let db = new SqlManager();
        return db.Get(SelectQuery.getMaterialPeaks, { PlantID: plantId, MaterialNo: parseInt(materialCode, 10) });
    }

}
