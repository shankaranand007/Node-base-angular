import { SqlManager } from '../helpers/sequelize';
import { SelectQuery, InsertQuery, UpdateQuery, DeleteQuery } from '../queries';
import { IProfile, IUsers } from '../entities';

export class ProfilesServiceManager {

    public async createProfile(profile: IProfile) {
        const db = new SqlManager();

        let insertPayload = {
            name: profile.Name,
            type: profile.Type,
            userid: profile.UserID,
            status: profile.Status,
            info: JSON.stringify(profile.Info),
            region: profile.Region,
            createdon: new Date(),
            createdby: profile.CreatedBy
        };

        await db.InsertAsync(InsertQuery.insertProfiles, insertPayload);
        return true;
    }

    public async updateProfile(profile: IProfile) {
        const db = new SqlManager();

        let updatePayload = {
            name: profile.Name,
            status: profile.Status,
            info: JSON.stringify(profile.Info),
            updateby: profile.UpdatedBy,
            updatedon: new Date(),
            id: profile.ID
        };

        await db.UpdateAsync(UpdateQuery.updateProfile, updatePayload);
        return true;
    }

    public async getGlobalProfiles() {
        const db = new SqlManager();

        let globalProfiles = await db.Get(SelectQuery.getGlobalProfiles, {});

        for (let profile of globalProfiles) {
            profile.Info = JSON.parse(profile.Info);
        }

        return globalProfiles;
    }

    public async getUserProfile(userID: string) {
        const db = new SqlManager();
        let userProfiles = [];

        if (userID !== null && userID !== undefined) {
            userProfiles = await db.GetAsync(SelectQuery.getUserSpecificProfiles, { userId: userID });
        } else {
            userProfiles = await db.GetAsync(SelectQuery.getUserProfiles, {});
        }

        for (let profile of userProfiles) {
            profile.Info = JSON.parse(profile.Info);
        }

        return userProfiles;
    }

    public getAllOflowUsers() {
        const db = new SqlManager();
        return db.Get(SelectQuery.getAllOflowUsers, {});
    }

    public updateUserAdminAccess(user: IUsers) {
        const db = new SqlManager();
        return db.Update(UpdateQuery.updateUserAdminAccess, user);
    }

    public userProfiles(userID: string) {
        const db = new SqlManager();

        return db.Get(SelectQuery.getUserSpecificProfiles, { userId: userID });
    }

    public updateStatus(profile: IProfile) {
        const db = new SqlManager();

        profile.UpdatedOn = new Date();
        return db.Update(UpdateQuery.updateProfileStatus, profile);
    }

    public async getDefaultProfile(userID: string) {
        const db = new SqlManager();

        let profileInfo: IProfile = await db.GetAsync(SelectQuery.getUsersDefaultProfile, { ID: userID });

        return profileInfo;
    }

    public setDefaultProfile(user: IUsers) {
        const db = new SqlManager();

        user.UpdatedOn = new Date();
        return db.Update(UpdateQuery.updateUserDefaultProfile, user);
    }

    public deleteProfile(profileID: string, updatedBy: string) {
        const db = new SqlManager();

        let params = {
            ID: profileID,
            UpdatedBy: updatedBy,
            UpdatedOn: new Date(),
        }

        return db.Delete(DeleteQuery.deleteProfileInfo, params);
    }

    public async createUser(user: IUsers) {
        const db = new SqlManager();

        await db.InsertAsync(InsertQuery.insertUser, user);

        return true;
    }
}
