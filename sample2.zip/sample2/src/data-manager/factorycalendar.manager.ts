import { SqlManager } from '../helpers/sequelize';
import { SelectQuery, InsertQuery, UpdateQuery, DeleteQuery } from '../queries';
import { IFactoryCalendarOverride } from '../entities/IFactoryCalendarOverride';
import { uniqBy, result, find } from "lodash";
import { IPlant, IDepartment, IFactoryCalendar } from '../entities';
import { MailManager } from './mail.manager';
import * as moment from 'moment';
import { String, StringBuilder } from 'typescript-string-operations';
import { AppSetting, IConfig } from '../config';
import { Utilities } from '../helpers';

export class FactoryCalendarServiceManager {

    public getHolidayStatus(PlantID: number, PeriodDate: Date) {
        let db = new SqlManager();

        const input = {
            plantID: PlantID,
            periodDate: PeriodDate
        };

        return db.Get(SelectQuery.getCheckForHoliday, input);
    }

    public getFactoryCalendar(calendarYear: number) {
        let db = new SqlManager();
        let responseData: any[] = [];
        return new Promise((resolve, reject) => {
            db.Get(SelectQuery.getDepartments, {}).then((departments) => {
                db.Get(SelectQuery.getFactoryCalendarOverrideByYear, { calendarYear: calendarYear }).then((facCalendar) => {
                    let factoryPlant = uniqBy(facCalendar, 'PlantID');
                    let factoryDate = uniqBy(facCalendar, 'OverrideDate');

                    for (let plant of factoryPlant) {
                        for (let facDate of factoryDate) {
                            let isExist = result(find(facCalendar, function (calendar) {
                                return calendar.PlantID === plant['PlantID']
                                    && calendar.OverrideDate === facDate['OverrideDate'];
                            }), 'DayIndicator');
                            if (isExist != null) {
                                let cal: IFactoryCalendarOverride = {
                                    PlantID: plant['PlantID'],
                                    OverrideDate: facDate['OverrideDate']
                                };
                                for (let department of departments) {
                                    let dayIndicator = result(find(facCalendar, function (calendar) {
                                        return calendar.PlantID === plant['PlantID']
                                            && calendar.OverrideDate === facDate['OverrideDate'] &&
                                            calendar.DepartmentCode === department['DepartmentCode'];
                                    }), 'DayIndicator');
                                    dayIndicator = dayIndicator !== undefined ? dayIndicator : '';
                                    cal[department['DepartmentName']] = dayIndicator;
                                }
                                responseData.push(cal);
                            }
                        }
                    }
                    resolve(responseData);
                }).catch(error => {
                    reject(error);
                });
            }).catch(error => {
                reject(error);
            });
        });
    }

    public getCalendarForDate(PlantID: number, OverrideDate: Date) {
        let db = new SqlManager();

        const input = {
            plantID: PlantID,
            overrideDate: OverrideDate
        };

        return db.Get(SelectQuery.getFactoryCalendarOverrideByPlantAndDate, input);
    }

    public async createCalendar(factoryCalendarOverride: IFactoryCalendarOverride[]) {
        let db = new SqlManager();
        let transaction = await db.InitiateTransactionAsync();

        try {
            for (let factoryCalendar of factoryCalendarOverride) {
                let existCheck = await db.Get(SelectQuery.getAllFactoryCalendarOverrideBy, { plantID: factoryCalendar.PlantID, departmentCode: factoryCalendar.DepartmentCode, overrideDate: factoryCalendar.OverrideDate.toString().split('T')[0] });
                if (existCheck.length <= 0) {
                    factoryCalendar.CreatedOn = factoryCalendar.CreatedOn == null ? new Date() : factoryCalendar.CreatedOn;
                    await db.InsertWithTransaction(InsertQuery.insertFactoryCalendarOverride, factoryCalendar, transaction);
                } else {
                    factoryCalendar.UpdatedOn = new Date();
                    factoryCalendar.IsActive = 'Y';
                    await db.UpdateWithTransaction(UpdateQuery.updateCalendar, factoryCalendar, transaction);
                }
            }
            await transaction.commit();
            return true;
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    }

    public async updateCalendar(factoryCalendarOverride: IFactoryCalendarOverride[]) {
        let db = new SqlManager();
        let transaction = await db.InitiateTransactionAsync();

        try {
            for (let factoryCalendar of factoryCalendarOverride) {
                let isExist = await db.GetAsync(SelectQuery.getAllFactoryCalendarOverrideBy, { plantID: factoryCalendar.PlantID, departmentCode: factoryCalendar.DepartmentCode, overrideDate: factoryCalendar.OverrideDate });
                if (isExist.length > 0) {
                    factoryCalendar.UpdatedOn = new Date();
                    await db.UpdateWithTransaction(UpdateQuery.updateCalendar, factoryCalendar, transaction);
                } else {
                    factoryCalendar.CreatedOn = new Date();
                    await db.InsertWithTransaction(InsertQuery.insertFactoryCalendarOverride, factoryCalendar, transaction);
                }
            }
            await transaction.commit();
            return true;
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    }

    public deleteCalendar(PlantID: number, OverrideDate: Date, DepartmentCode: string) {
        let db = new SqlManager();

        const input = {
            plantID: PlantID,
            overrideDate: OverrideDate,
            departmentCode: DepartmentCode
        };

        let query = DepartmentCode !== null && DepartmentCode !== undefined ? DeleteQuery.deleteFactoryCalendarOverride : DeleteQuery.deleteFactoryCalendarOverrideAllDept;
        return db.Insert(query, input);
    }

    public async generateFactoryCalendarRunningNumbers(createdBy: string) {
        let db = new SqlManager();
        let app: IConfig = AppSetting.getConfig();
        let transaction = await db.InitiateTransactionAsync();
        let processStartTime = new Date(); let processEndTime = null;

        try {
            let plantsCol: IPlant[] = await db.Get(SelectQuery.getPlants, {})
            let departmentsCol: IDepartment[] = await db.Get(SelectQuery.getDepartments, {});

            for (let plant of plantsCol) {
                let bulkInsert: any[] = []; let bulkUpdate: any[] = [];

                for (let department of departmentsCol) {
                    let calendarDays = await db.Get(SelectQuery.getoFlowFactoryWorkDayForDepartment, { CalendarID: plant.CalendarID, DepartmentCode: department.DepartmentCode, PlantID: plant.PlantID });
                    let existingFacCalendar: IFactoryCalendar[] = await db.Get(SelectQuery.getFactoryCalendarByPlantDateAndDept, { PlantID: plant.PlantID, DepartmentCode: department.DepartmentCode });

                    calendarDays.reduce((previouscalDay, calDay, index) => { // This will compare previous and current date flag and assign new running number
                        calDay["FactoryDayNum"] = previouscalDay['FactoryDayNum'] ? previouscalDay['FactoryDayNum'] : 1;
                        if (index === 0) {
                            calDay["FactoryDayNum"] = 1;
                        } else if (previouscalDay['oFlowWorkingdayIndicator'] === 'N' && previouscalDay["FactoryDayNum"] === 1) {
                            calDay["FactoryDayNum"] = calDay["FactoryDayNum"];
                        } else if (calDay['oFlowWorkingdayIndicator'] === 'Y') {
                            calDay["FactoryDayNum"] = calDay["FactoryDayNum"] + 1;
                        }

                        let isExist = find(existingFacCalendar, function (cal) { return cal.PlantID === plant.PlantID && cal.DepartmentCode === department.DepartmentCode && moment.utc(cal.CalendarDate).format('YYYY-MM-DD') === moment.utc(calDay['PeriodDate']).format('YYYY-MM-DD'); });
                        if (isExist) {
                            bulkUpdate.push({
                                PlantID: plant.PlantID,
                                CalendarDate: calDay['PeriodDate'],
                                DepartmentCode: department.DepartmentCode,
                                DayIndicator: calDay['oFlowWorkingdayIndicator'],
                                FactoryDay: calDay['FactoryDayNum'],
                                IsActive: 'Y',
                                UpdatedOn: new Date(),
                                UpdatedBy: createdBy
                            });
                        } else {
                            bulkInsert.push({
                                PlantID: plant.PlantID,
                                CalendarDate: calDay['PeriodDate'],
                                DepartmentCode: department.DepartmentCode,
                                DayIndicator: calDay['oFlowWorkingdayIndicator'],
                                FactoryDay: calDay['FactoryDayNum'],
                                IsActive: 'Y',
                                CreatedOn: new Date(),
                                CreatedBy: createdBy
                            });
                        }
                        return calDay;
                    }, {});
                }
                if (bulkInsert.length > 0) { db.BulkInsertWithTransaction('FactoryCalendar', bulkInsert, transaction); }
                if (bulkUpdate.length > 0) { db.BulkUpdateWithTransaction('FactoryCalendar', bulkUpdate, transaction); }
            }

            await transaction.commit();
            processEndTime = new Date();
            let totalTimeTaken = processEndTime.getTime() - processStartTime.getTime();
            const emailContent = await MailManager.getMailContent('factory-calendar.html');
            let totalTime = Utilities.milliSecToMinutesAndSeconds(totalTimeTaken);
            const builder = new StringBuilder();
            builder.AppendFormat(emailContent, totalTime.minutes + ':' + totalTime.seconds);
            MailManager.sendMail('oFlow :: Factory Calendar Day Generation', app.DefaultToEmail, builder.ToString());
        } catch (error) {
            await transaction.rollback();
            throw error;
        }
    }
}
