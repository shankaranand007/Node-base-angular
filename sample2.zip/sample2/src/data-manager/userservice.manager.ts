import * as request from 'request';
import { AppSetting } from '../config';
import { SqlManager } from '../helpers/sequelize';
import { SelectQuery, InsertQuery, UpdateQuery, DeleteQuery } from '../queries';
import { IUsers } from '../entities';

export class UserServiceManager {

    private async getMDRUser(email: string) {
        return new Promise((resolve, reject) => {
            let config = AppSetting.getConfig();
            request(config.MDR['user'].url + "?emailids=" + email, (error, response, body) => {
                if (error) {
                    reject(error);
                } else {
                    let result = JSON.parse(body);
                    if (result && result.users && result.users.length) {
                        const val = {
                            UserId: result.users[0].globaluserid,
                            DisplayName: result.users[0].displayname != null ? result.users[0].displayname : result.users[0].firstname + ' ' + result.users[0].lastname,
                            EmailId: result.users[0].email,
                            OfficeLocation: result.users[0].deptcode,
                            Position: result.users[0].position,
                            Region: result.users[0].regionname,
                            DeptName: result.users[0].deptname
                        };
                        resolve(val);
                    }
                    resolve();
                }
            });
        });
    }

    public async getUser(email: string) {
        const db = new SqlManager();
        let user = await this.getMDRUser(email);
        let oflowUserProfile = await db.Get(SelectQuery.getOflowUser, { UserID: user["UserId"] });
        user['IsAdmin'] = oflowUserProfile.length > 0 ? oflowUserProfile[0].IsAdmin : 'N';
        return user;
    }

    public getSearchUser(name: string) {
        let config = AppSetting.getConfig();
        let userResult = [];

        return new Promise((resolve, reject) => {
            request(config.MDR['user'].url + "?$filter=contains(fullname," + name + ") or contains(globaluserid," + name + ")", (error, response, body) => {
                if (error) {
                    reject(error);
                } else {
                    let result = JSON.parse(body);
                    if (result && result.users && result.users.length) {
                        for (let user of result.users) {
                            let val = {
                                UserId: user.globaluserid,
                                DisplayName: user.displayname != null ? user.displayname : user.firstname + ' ' + user.lastname,
                                EmailId: user.email,
                                OfficeLocation: user.deptcode,
                                Position: user.position,
                                Region: user.regionname,
                                DeptName: user.deptname
                            };
                            userResult.push(val);
                        }
                    }
                    resolve(userResult);
                }
            });
        });
    }

    public updateLastLogin(user: IUsers) {
        const db = new SqlManager();

        user.LastLogin = new Date();
        user.UpdatedOn = new Date();
        return db.Update(UpdateQuery.updateLastLogin, user);
    }
}
