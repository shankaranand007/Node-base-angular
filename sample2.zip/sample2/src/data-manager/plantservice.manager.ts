import { SqlManager } from '../helpers/sequelize';
import { SelectQuery, InsertQuery, UpdateQuery, DeleteQuery } from '../queries';
import { IPlant } from '../entities';


export class PlantServiceManager {

    public getPlants() {
        let db = new SqlManager();
        return db.Get(SelectQuery.getPlants, {});
    }

    public getPlantInfo(plantId) {
        let db = new SqlManager();

        let input = {
            plantId: plantId
        };
        return db.Get(SelectQuery.getPlant, input);
    }

    public getDepartments() {
        let db = new SqlManager();
        return db.Get(SelectQuery.getDepartments, {});
    }

    public getDepartment(departmentCode) {
        let db = new SqlManager();

        let input = {
            departmentCode: departmentCode
        };

        return db.Get(SelectQuery.getDepartments, input);
    }

    public getMrps(plants: any) {
        let db = new SqlManager();

        return db.Get(SelectQuery.getMRPsForPlant, { PlantID: plants });
    }

    public getSiteGroup(plants: any) {
        let db = new SqlManager();

        return db.Get(SelectQuery.getSalesGroupForPlant, { PlantID: plants });
    }

}
