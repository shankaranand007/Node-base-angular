export interface IMaterialSubstitution {
    PlantID: string;
    DocType?: string;
    SubType: string;
    MaterialFrom: string;
    MaterialTo: string;
    ValidFrom?: Date;
    ValidTo?: Date;
    Status?: string;
    CreatedBy?: string;
    CreatedOn?: Date;
    UpdatedBy?: string;
    UpdatedOn?: Date;
}
