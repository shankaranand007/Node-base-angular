export interface IPlant {
    PlantID: string;
    PlantName: string;
    SiteName: string;
    PlantType: string;
    Region: string;
    BusinessUnit: string;
    Country: string;
    City: string;
    CalendarID: string;
    GeoLocation: string;
}
