export interface IUsers {
    ID: string;
    Name: string;
    DefaultProfileID: number;
    IsAdmin: string;
    LastLogin: Date;
    CreatedOn?: Date;
    CreatedBy?: string;
    UpdatedOn?: Date;
    UpdatedBy?: string;
}
