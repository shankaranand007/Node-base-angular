export interface IMRPS {
    PlantID: string;
    MateriaNo: string;
    MRPController: string;
}
