export interface ISalesGroup {
    SalesGroup: string;
    SalesGroupDesc: string;
    SalesOrganization: string;
    SalesOrganizationDesc: string;
    DistributionChannel: string;
    Division: string;
    SalesOffice: string;
    SalesOfficeDesc: string;
    Vendor: string;
}
