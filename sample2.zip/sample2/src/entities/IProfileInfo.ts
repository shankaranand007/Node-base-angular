export interface IProfileInfo {
    FRAG: [{ PlantID?: string }];
    FLAV: [{ PlantID?: string }];
    FI: [{ PlantID?: string }];
    MRPS: [{ ID?: string }];
    SALESGRP: [{ ID?: string }];
    SETTINGS: { LocaleValue?: string, DateFormat?: string, TimeFormat?: string, CurrentyFormat?: string, CurrentySymbole?: string, DecimalPlace?: number, DecimalChar?: string };
}
