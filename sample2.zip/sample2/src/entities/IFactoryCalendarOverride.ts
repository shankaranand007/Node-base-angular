export interface IFactoryCalendarOverride {
    PlantID: string;
    PlantCode?: string;
    OverrideDate?: Date;
    DepartmentCode?: any;
    DayIndicator?: string;
    IsActive?: string;
    CreatedOn?: Date;
    CreatedBy?: string;
    UpdatedOn?: Date;
    UpdatedBy?: string;
}
