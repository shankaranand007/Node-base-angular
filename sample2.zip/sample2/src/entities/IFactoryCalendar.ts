export interface IFactoryCalendar {
    PlantID: string;
    CalendarDate: Date;
    DepartmentCode: string;
    DayIndicator: string;
    FactoryDay: number;
    IsActive: string;
    CreatedBy?: string;
    CreatedOn?: Date;
    UpdatedBy?: string;
    UpdatedOn?: Date;
}
