export interface IDepartment {
    DepartmentCode: string;
    DepartmentName: string;
    CreatedBy: string;
    CreatedOn: Date;
    UpdatedBy: string;
    UpdatedOn: Date;
}
