import { IProfileInfo } from "./IProfileInfo";

export interface IProfile {
    ID?: string;
    Name: string;
    Type: string;
    UserID?: string;
    Status: string;
    Region: string;
    Info: IProfileInfo;
    IsDefaultProfile: string;
    UserName: string;
    CreatedOn?: Date;
    CreatedBy?: string;
    UpdatedOn?: Date;
    UpdatedBy?: string;
}
