export const environment = {
  production: true,

  authRedirectUri: window.location.origin + '/login',
  authPostLogoutRedirectUri: window.location.origin + '/login',
  authClientId: '0oa1fxs7ktcUMkthz0h8',
  authIssuer: 'https://iff.okta.com',

  appApi: 'api/',
  userApi: '_user_api/'
};
