import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, PreloadAllModules } from '@angular/router';
import { NgModule } from '@angular/core';
import { NgMaterialModule } from './material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2Piwik } from 'angulartics2/piwik';

import { ROUTES } from './app.router';
import { OAuthModule } from 'angular-oauth2-oidc-cache';
import { AuthGuard } from './_shared/okta/auth.guard';
import { AppResolver } from './app.resolver';
import { AppData } from './app.data';
import { AppBroadCast } from './_services';
import { AppState, InternalStateType } from './_services';
import { NoContentComponent, AppLoadingComponent } from './_shared/components';
import { DeleteDialogComponent } from './_shared/components/deletedialog/deletedialog.component';
import { APP_INITIALIZER } from '@angular/core';
import { AppComponent } from './app.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { RMPModule } from './material/RMP-dashboard/RPM.module';
import { MasterPlanningModule } from './material/MasterPlanningDashboard/master-planning.module';
import { HomeModule } from './home/home.module';
import { AdminModule } from './admin/admin.module';
import { LoginComponent } from './_shared/okta/login.component';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { ToastrModule } from 'ngx-toastr';
import { SharedModule } from './_shared/components/share.module';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NoContentComponent,
    AppLoadingComponent,
    UnauthorizedComponent,
    DeleteDialogComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CommonModule,
    RouterModule.forRoot(ROUTES, { useHash: false, preloadingStrategy: PreloadAllModules }),
    OAuthModule.forRoot(),
    NgMaterialModule,
    HomeModule,
    RMPModule,
    MasterPlanningModule,
    AdminModule,
    LoggerModule.forRoot({ serverLogLevel: NgxLoggerLevel.OFF, level: NgxLoggerLevel.TRACE }),
    ToastrModule.forRoot(),
    Angulartics2Module.forRoot([Angulartics2Piwik]),
    SharedModule
  ],
  providers: [
    AppData,
    AppState,
    AppResolver,
    {
      provide: APP_INITIALIZER,
      useFactory: (config: AppResolver) => () => config.validateUser(),
      deps: [AppResolver],
      multi: true
    },
    AppBroadCast,
    AuthGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    DeleteDialogComponent
  ]
})
export class AppModule { }
