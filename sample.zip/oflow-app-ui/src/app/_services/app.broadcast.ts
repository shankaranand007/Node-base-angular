import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class AppBroadCast {

    private _showHeader = new Subject<any>();
    public showHeader = this._showHeader.asObservable();
    private _currentUser = new Subject<any>();
    public subCurrentUser = this._currentUser.asObservable();
    public subMenu = new Subject<any>();
    public showSubmenu = this.subMenu.asObservable();

    public pubShowHeader(value: any) {
        this._showHeader.next(value);
    }

    public pubCurrentUser(value: any) {
        this._currentUser.next(value);
    }
    public pubShowMenu(value: any) {
        this.subMenu.next(value);
    }
}
