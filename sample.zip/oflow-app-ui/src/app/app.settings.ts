export class AppSettings {
    public static isDebugMode = true;
    public static AppName = 'oFlow';
    public static AppVersion = '1.0';
    public static AppUrl = {
        api: './app-api/',
    };
}
