import { Injectable } from '@angular/core';
import { OAuthService, JwksValidationHandler } from 'angular-oauth2-oidc-cache';
import { authConfig } from './_shared/okta/auth.config';
import { AppBroadCast } from './_services/app.broadcast';
import { AppData } from './app.data';
import { AppState } from './_services';
import 'rxjs/add/operator/toPromise';
import { retry } from 'rxjs/operator/retry';
import { concat } from 'rxjs/observable/concat';

@Injectable()
export class AppResolver {

    constructor(
        private appData: AppData,
        private appState: AppState,
        private pubSub: AppBroadCast,
        private oAuthSvc: OAuthService
    ) { }

    public configureJWT() {
        this.oAuthSvc.configure(authConfig);
        this.oAuthSvc.tokenValidationHandler = new JwksValidationHandler();
        this.oAuthSvc.setupAutomaticSilentRefresh();
    }
    public validateUser() {
        let isInvalidLogin;
        localStorage.removeItem('okta-token-storage');
        this.configureJWT();

        return new Promise((resolve, reject) => {
            this.oAuthSvc.loadDiscoveryDocument().then((doc) => {
                this.oAuthSvc.tryLogin({
                    onTokenReceived: (context) => {
                        this.appState.set(this.appState.stateId.RedirectUri, context.state);
                        const claims: any = this.oAuthSvc.getIdentityClaims();
                        this.updateUserInfo(claims, resolve);
                    },
                    onLoginError: (context) => {
                        isInvalidLogin = true;
                        this.appState.set(this.appState.stateId.isAccessDenied, true);
                        resolve(true);
                    }
                });
                if (!this.oAuthSvc.hasValidIdToken() && !this.oAuthSvc.hasValidAccessToken()) {
                    if (!isInvalidLogin) {
                        this.oAuthSvc.initImplicitFlow(window.location.pathname);
                    }
                } else {
                    const claims: any = this.oAuthSvc.getIdentityClaims();
                    this.updateUserInfo(claims, resolve);
                }
            }).catch((err) => {
                reject(err);
            });

        });
    }

    private updateUserInfo(claims: any, resolve: any) {
        if (claims) {
            this.appState.set(this.appState.stateId.token, this.oAuthSvc.getAccessToken());
            this.appData.get(this.appData.url.userByEmail, [claims.email]).subscribe((result) => {
                // alert('exists');
                const user = {
                    Id: result['UserId'],
                    DisplayName: result['DisplayName'], // result[0]['displayname'],
                    Email: result['EmailId'],
                    Position: result['Position'],
                    Region: result['Region'],
                    DeptName: result['DeptName'],
                    OfficeLocation: result['OfficeLocation'],
                    IsAdmin: result['IsAdmin']
                };
                this.appState.set(this.appState.stateId.userInfo, user);
                resolve(claims);
                // this.pubSub.pubShowHeader({ showHeader: true, displayName: claims.name });
            });
        }
    }
}
