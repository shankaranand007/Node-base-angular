import { Routes } from '@angular/router';
import { AuthGuard } from './_shared/okta/auth.guard';
import { HomeComponent } from './home/home.component';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { FactoryCalendarComponent } from './admin/factoryCalendar/factorycalendar.component';
import { ProfileComponent } from './admin/profile/profile.component';
import { PrivilegeComponent } from './admin/privilege/privilege.component';
import { NoContentComponent } from './_shared/components';
import { LoginComponent } from './_shared/okta/login.component';

export const ROUTES: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  {
    path: 'material/master',
    loadChildren: './material/MasterPlanningDashboard/master-planning.module#MasterPlanningModule'
  },
  {
    path: 'material/RMP',
    loadChildren: './material/RMP-dashboard/RPM.module#RMPModule'
  },
  { path: 'admin/factorycalendar', component: FactoryCalendarComponent, canActivate: [AuthGuard] },
  { path: 'admin/privilege', component: PrivilegeComponent, canActivate: [AuthGuard] },
  { path: 'admin/profile/:profileType', component: ProfileComponent, canActivate: [AuthGuard] },

  { path: '**', component: NoContentComponent },
];
