import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'unauthorized',
    styleUrls: ['./unauthorized.component.css'],
    templateUrl: './unauthorized.component.html',
})
export class UnauthorizedComponent implements OnInit {

    constructor() {
        // Code
    }

    public ngOnInit() {
        console.log('hello `Error` component');
    }

}
