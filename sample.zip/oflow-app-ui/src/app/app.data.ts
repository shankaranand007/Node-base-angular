import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';
import { OAuthService } from 'angular-oauth2-oidc-cache';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppSettings } from './app.settings';
import { AppState } from './_services';
import { Md5 } from 'ts-md5/dist/md5';

import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class AppData {

    public url = {
        userByEmail: AppSettings.AppUrl.api + 'users?emailIds={0}',
        userPhoto: AppSettings.AppUrl.api + 'users/{0}/photo',
        createUser: AppSettings.AppUrl.api + 'profile/user',
        getPlant: AppSettings.AppUrl.api + 'plant/',
        getDepartment: AppSettings.AppUrl.api + 'plant/department',
        getMrps: AppSettings.AppUrl.api + 'plant/mrps',
        getSiteGroup: AppSettings.AppUrl.api + 'plant/sitegroup',
        getPlantInfo: AppSettings.AppUrl.api + 'plant/{0}',
        createCalendar: AppSettings.AppUrl.api + 'calendar/',
        updateCalendar: AppSettings.AppUrl.api + 'calendar/',
        getCalendar: AppSettings.AppUrl.api + 'calendar/{0}',
        getDateStatus: AppSettings.AppUrl.api + 'calendar/holiday/{0}/{1}',
        deleteCalendar: AppSettings.AppUrl.api + 'calendar/{0}/{1}',
        singleDelete: AppSettings.AppUrl.api + 'calendar/{0}/{1}/{2}',
        getUserProfile: AppSettings.AppUrl.api + 'profile/user',
        getParticularUserProfile: AppSettings.AppUrl.api + 'profile/{0}/userprofiles',
        getDefaultProfile: AppSettings.AppUrl.api + 'profile/{0}/defaultprofiles',
        setDefaultProfile: AppSettings.AppUrl.api + 'profile/setdefaultprofile',
        getGlobalProfile: AppSettings.AppUrl.api + 'profile/global',
        searchUserByName: AppSettings.AppUrl.api + 'users/searchusersbyname/{0}',
        createProfile: AppSettings.AppUrl.api + 'profile/',
        updateProfile: AppSettings.AppUrl.api + 'profile/',
        updateProfileStatus: AppSettings.AppUrl.api + 'profile/updateStatus',
        deleteProfile: AppSettings.AppUrl.api + 'profile/{0}',
        getAllUser: AppSettings.AppUrl.api + 'profile/user/all',
        updateAdminprivilege: AppSettings.AppUrl.api + 'profile/user/{0}',
        createSubstitution: AppSettings.AppUrl.api + 'materials/',
        getSubstitution: AppSettings.AppUrl.api + 'materials/',
        deleteSubstitution: AppSettings.AppUrl.api + 'materials/substitution/{0}/{1}/{2}',
        getMaterialCode: AppSettings.AppUrl.api + 'materials/code/{0}/{1}',
        updateSubstitution: AppSettings.AppUrl.api + 'materials/',
    };

    constructor(private http: HttpClient, private appState: AppState, private oAuthSvc: OAuthService) { }


    public get(qry: string, prm: string[]): Observable<any> {
        const heads = {
            'Cache-control': 'no-cache,no-store',
            'Expires': '0',
            'Pragma': 'no-cache',
            'x-access-token': this.getToken(),
            'x-userid': this.getId()
        };
        const options = { headers: heads, withCredentials: true };
        const aQry = this.formatQuery(qry, prm);
        return this.http.get(aQry, options);
    }

    public delete(qry: string, prm: string[]): Observable<any> {
        const heads = {
            'Cache-control': 'no-cache,no-store',
            'Expires': '0',
            'Pragma': 'no-cache',
            'x-access-token': this.getToken(),
            'x-userid': this.getId()
        };
        const options = { headers: heads, withCredentials: true };
        const aQry = this.formatQuery(qry, prm);
        return this.http.delete(aQry, options);
    }

    public getCached(qry: string, prm: string[]): Observable<any> {
        const heads = {
            'x-access-token': this.getToken(),
            'x-userid': this.getId()
        };
        const options = { headers: heads, withCredentials: true };
        const aQry = this.formatQuery(qry, prm);
        if (this.appState.get(aQry)) {
            return Observable.of(this.appState.get(aQry));
        } else {
            return this.http.get(aQry, options)
                .map((response) => {
                    this.appState.set(aQry, response);
                    return response;
                });
        }
    }

    public post(qry: string, prm: any[], data: any) {
        const hdr = {
            'Content-Type': 'application/json',
            'x-access-token': this.getToken(),
            'x-userid': this.getId()
        };
        const options = { headers: hdr };
        const aQry = this.formatQuery(qry, prm);
        return this.http.post(aQry, data, options);
    }

    public put(qry: string, prm: any[], data: any) {
        const hdr = {
            'Content-Type': 'application/json',
            'accept': 'application/json',
            'x-access-token': this.getToken(),
            'x-userid': this.getId()
        };
        const options = { headers: hdr };
        const aQry = this.formatQuery(qry, prm);
        return this.http.put(aQry, data, options);
    }

    public getImageUrl(qry: string, prm: any[]) {
        return this.formatQuery(qry, prm);
    }

    private formatQuery(qry: string, prm: string[]) {
        let theString = arguments[0];
        if (arguments.length !== 2) {
            return theString;
        }

        const theParams = arguments[1];
        for (let i = 0; i < theParams.length; i++) {
            if (theParams[i] !== undefined && theParams[i] !== null) {
                // tslint:disable-next-line:quotemark
                const regEx = new RegExp("\\{" + i + "\\}", "gm");
                theString = theString.replace(regEx, theParams[i]);
            }
        }
        return theString;
    }
    public getToken() {
        return this.oAuthSvc.getIdToken();
    }

    public getId() {
        return this.appState.get(this.appState.stateId.userInfo) ? this.appState.get(this.appState.stateId.userInfo).Id : 'mxj1234';
    }
}
