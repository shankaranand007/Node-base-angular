import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { MaterialDetailKeyComponent } from './material-detail-key/material-detail-key.component';
import { AppState, AppBroadCast } from '../../../_services';

@Component({
  selector: 'app-material-detail',
  templateUrl: './material-detail.component.html',
  styleUrls: ['./material-detail.component.css']
})
export class MaterialDetailComponent implements OnInit {

  constructor(public dialog: MatDialog, private pubSub: AppBroadCast) { }

  ngOnInit() {
    this.pubSub.pubShowMenu('materialdetail');
  }

  openDetail() {
    const createDialogRef = this.dialog.open(MaterialDetailKeyComponent, {
      disableClose: true,
      width: '868px',
      data: {}
    });

    createDialogRef.afterClosed().subscribe(record => {

    });
  }

}
