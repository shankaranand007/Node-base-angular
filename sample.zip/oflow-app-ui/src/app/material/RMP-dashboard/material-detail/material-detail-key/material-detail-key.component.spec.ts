import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialDetailKeyComponent } from './material-detail-key.component';

describe('MaterialDetailKeyComponent', () => {
  let component: MaterialDetailKeyComponent;
  let fixture: ComponentFixture<MaterialDetailKeyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaterialDetailKeyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaterialDetailKeyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
