import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatSort, MatTableDataSource } from '@angular/material';
@Component({
  selector: 'app-material-detail-key',
  templateUrl: './material-detail-key.component.html',
  styleUrls: ['./material-detail-key.component.css']
})
export class MaterialDetailKeyComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<MaterialDetailKeyComponent>,
    @Inject(MAT_DIALOG_DATA) public data) { }
  public displayedColumns = ['status', 'proplo', 'Number', 'Req', 'Stat', 'Qty', 'Tot', 'ReqDate', 'WeekNum'];
  public dataSource = new MatTableDataSource(ELEMENT_DATA);
  ngOnInit() {
  }

}

export interface PeriodicElement {
  status: string;
  proplo: string;
  Number: string;
  Req: string;
  Stat: string;
  Qty: string;
  Tot: string;
  ReqDate: string;
  WeekNum: string;

}

const ELEMENT_DATA: PeriodicElement[] = [
  { status: '', proplo: 'PLPO', Number: '00020324', Req: '307789401', Stat: ' ', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'MANC', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'MANC', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'MANC', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: '', proplo: 'PLPO', Number: '00020324', Req: '207712334', Stat: '', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: '', proplo: 'PLPO', Number: '00020324', Req: '000773234', Stat: '', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: '', proplo: 'PLPO', Number: '00020324', Req: '307789401', Stat: '', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'PCNF', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'PCNF', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'MANC', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' },
  { status: 'Department', proplo: 'PRO', Number: '00020324', Req: '307789401', Stat: 'MANC', Qty: '0.026163', Tot: '0.026163', ReqDate: '19 Feb 18', WeekNum: 'CW' }

];
