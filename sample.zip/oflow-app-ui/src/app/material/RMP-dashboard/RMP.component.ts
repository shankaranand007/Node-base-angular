import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppBroadCast } from '../../_services';

@Component({
  selector: 'app-rmp',
  templateUrl: './RMP.component.html',
  styleUrls: ['./RMP.component.css']
})
export class RMPComponent implements OnInit {

  public userInfo: string = '';
  public isDraweropen: boolean = false;
  public isDrawernavopen: boolean = false;
  public isShow: boolean = false;
  public activeSubMenu: any;

  constructor(private router: Router, private pubSub: AppBroadCast) { }

  ngOnInit() {
    this.pubSub.showSubmenu.subscribe((data) => {
      this.activeSubMenu = data;
    });
  }

  public navigateRouter(params: string) {
    this.router.navigate([params]);
  }

  public draweropen() {
    this.isDraweropen = !this.isDraweropen;
  }
  public drawernavopen() {
    this.isDrawernavopen = !this.isDrawernavopen;
  }

  public toggleSearch() {
    this.isShow ? this.isShow = false : this.isShow = true;
  }

}
