import { Component, OnInit, ViewChild } from '@angular/core';
import { AppState, AppBroadCast } from '../../../_services';
import { AppData } from '../../../app.data';
import { NGXLogger } from 'ngx-logger';
import { MatSort, MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-urgent',
  templateUrl: './urgent-material.component.html',
  styleUrls: ['./urgent-material.component.css']
})
export class UrgentMaterialComponent implements OnInit {

  public userInfo = '';
  public isDraweropen = false;
  public isDrawernavopen = false;
  public isShow = false;
  public displayedColumns = ['status', 'plant', 'material', 'matdesc', 'oFlowRec', 'mrp', 'Aff', 'SL2', 'RunOut', 'AvailDate', 'NextPO', 'Action'];
  public dataSource = new MatTableDataSource(ELEMENT_DATA);
  constructor(private appState: AppState, private appData: AppData, private logger: NGXLogger, private pubSub: AppBroadCast) {
  }
  @ViewChild(MatSort) sort: MatSort;
  public ngOnInit() {
    this.dataSource.sort = this.sort;
    this.pubSub.pubShowMenu('urgent');
  }
  draweropen() {
    this.isDraweropen = !this.isDraweropen;
  }
  drawernavopen() {
    this.isDrawernavopen = !this.isDrawernavopen;
  }

  openMaterialDetail() {
    let params = '';
    params = 'width=' + screen.width;
    params += ', height=' + screen.height;
    params += ', top=0, left=0';
    params += ', fullscreen=yes,directories=no,titlebar=yes,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no';
    const path = '/material/rmp/materialdetail/234';
    window.open(path, 'RawMaterialDetail', params);
  }

  toggleSearch() {
    this.isShow ? this.isShow = false : this.isShow = true;
  }
}
export interface PeriodicElement {
  status: string;
  plant: string;
  material: string;
  matdesc: string;
  oFlowRec: string;
  mrp: string;
  Aff: string;
  SL2: string;
  RunOut: string;
  AvailDate: string;
  NextPO: string;
  Action: string;
  Old: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { status: 'BusinessUnit', plant: '0012', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'Y' },
  { status: 'BusinessUnit', plant: '0013', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB 27 Nov 18', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'BusinessUnit', plant: '0014', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'BusinessUnit', plant: '0015', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'Region', plant: '0012', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'Y' },
  { status: 'Region', plant: '0013', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'Planning', plant: '0014', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'Planning', plant: '0013', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'Department', plant: '0014', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'Department', plant: '0013', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' },
  { status: 'Department', plant: '0013', material: '00020324', matdesc: 'BUTYL-6-METH PHENOL,22-TERT,', oFlowRec: 'Act-Req', mrp: '1Rs', Aff: '0', SL2: '1', RunOut: '19 Feb 18', AvailDate: '19 Feb 18', NextPO: '4503052898 AB', Action: 'RMP-Alternate Vendor-new vendor MRC/can be left out from below | [LXL1476] Feb 2018 08:53:38', Old: 'N' }

];
