import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RMPComponent } from './RMP.component';

describe('RMPComponent', () => {
  let component: RMPComponent;
  let fixture: ComponentFixture<RMPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RMPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RMPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
