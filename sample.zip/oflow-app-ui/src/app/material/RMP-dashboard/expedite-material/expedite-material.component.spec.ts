import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpediteMaterialComponent } from './expedite-material.component';

describe('ExpediteMaterialComponent', () => {
  let component: ExpediteMaterialComponent;
  let fixture: ComponentFixture<ExpediteMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpediteMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpediteMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
