import { Component, OnInit } from '@angular/core';
import { AppState, AppBroadCast } from '../../../_services';

@Component({
  selector: 'app-expedite-material',
  templateUrl: './expedite-material.component.html',
  styleUrls: ['./expedite-material.component.css']
})
export class ExpediteMaterialComponent implements OnInit {

  constructor(private pubSub: AppBroadCast) {
  }

  ngOnInit() {
    this.pubSub.pubShowMenu('expedite');
  }

}
