import { Component, OnInit } from '@angular/core';
import { AppState, AppBroadCast } from '../../../_services';

@Component({
  selector: 'app-proactive-material',
  templateUrl: './proactive-material.component.html',
  styleUrls: ['./proactive-material.component.css']
})
export class ProactiveMaterialComponent implements OnInit {

  constructor(private pubSub: AppBroadCast) {
  }

  ngOnInit() {
    this.pubSub.pubShowMenu('proactive');
  }

}
