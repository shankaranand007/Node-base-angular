import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProactiveMaterialComponent } from './proactive-material.component';

describe('ProactiveMaterialComponent', () => {
  let component: ProactiveMaterialComponent;
  let fixture: ComponentFixture<ProactiveMaterialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProactiveMaterialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProactiveMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
