import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthGuard } from '../../_shared/okta/auth.guard';
import { RMPComponent } from './RMP.component';
import { NgMaterialModule } from '../../material.module';
import { UrgentMaterialComponent } from './urgent-material/urgent-material.component';
import { ExpediteMaterialComponent } from './expedite-material/expedite-material.component';
import { ProactiveMaterialComponent } from './proactive-material/proactive-material.component';
import { MaterialDetailComponent } from './material-detail/material-detail.component';
import { MaterialDetailKeyComponent } from './material-detail/material-detail-key/material-detail-key.component';
import { RmpRoutingModule } from './RMP-routing.module';

@NgModule({
    imports: [
        CommonModule,
        RmpRoutingModule,
        FormsModule,
        NgMaterialModule
    ],
    declarations: [
        RMPComponent,
        UrgentMaterialComponent,
        ExpediteMaterialComponent,
        ProactiveMaterialComponent,
        MaterialDetailComponent,
        MaterialDetailKeyComponent,
    ],
    providers: [AuthGuard],
    entryComponents: [
        MaterialDetailKeyComponent
    ],
})
export class RMPModule { }
