import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../_shared/okta/auth.guard';
import { RMPComponent } from './RMP.component';
import { UrgentMaterialComponent } from './urgent-material/urgent-material.component';
import { ExpediteMaterialComponent } from './expedite-material/expedite-material.component';
import { ProactiveMaterialComponent } from './proactive-material/proactive-material.component';
import { MaterialDetailComponent } from './material-detail/material-detail.component';

const RMPRouting: Routes = [{
    path: 'material/rmp',
    component: RMPComponent,
    children: [
        { path: '', redirectTo: 'urgent', pathMatch: 'full' },
        { path: 'urgent', component: UrgentMaterialComponent, canActivate: [AuthGuard] },
        { path: 'expedite', component: ExpediteMaterialComponent, canActivate: [AuthGuard] },
        { path: 'proactive', component: ProactiveMaterialComponent, canActivate: [AuthGuard] },
        { path: 'materialdetail/:materialId/:tabId', component: MaterialDetailComponent, canActivate: [AuthGuard] },
        { path: '**', redirectTo: 'urgent' }
    ]
}];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(RMPRouting)
    ],
    exports: [RouterModule],
    declarations: [],
    providers: [AuthGuard],
})
export class RmpRoutingModule { }
