import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialSubstitutionComponent } from './material-substitution.component';

describe('MaterialSubstitutionComponent', () => {
  let component: MaterialSubstitutionComponent;
  let fixture: ComponentFixture<MaterialSubstitutionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaterialSubstitutionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaterialSubstitutionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
