import { Component, OnInit, Inject } from '@angular/core';
import { AppData } from '../../../../app.data';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { businessUnits, dialogMode, profileStatusType } from '../../../../_shared/interface/dialogEnum';
import { IMaterialSubstitution } from 'oflow.entities';
import { FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { filter, cloneDeep } from 'lodash';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-createdialogue',
  templateUrl: './createdialogue.component.html',
  styleUrls: ['./createdialogue.component.css']
})
export class CreatedialogueComponent implements OnInit {
  public formValues: any = {};
  public loading: boolean = false;
  public plantControl = new FormControl('', [Validators.required]);
  public materialFrom = new FormControl('', [Validators.required]);
  public materialTo = new FormControl('', [Validators.required]);
  public materialCode: any[] = [];
  public filteredMaterialFrom: Observable<any[]>;
  public filteredMaterialTo: Observable<any[]>;
  public selectPlantOptions: any = [];
  public Options = {
    FRAG: ['E&R', 'Allowed Substitution', 'Allocation Sub', 'Permanent Sub', 'Pending E&R', 'Exclude from Formula', 'PFG (Protected Finished Goods)'],
    FLAV: ['E&R', 'Allowed Substitution', 'Allocation Sub', 'Permanent Sub', 'Pending E&R', 'Exclude from Formula', 'Key Base Mgmt']
  };

  constructor(private appData: AppData, private notification: ToastrService, public dialogRef: MatDialogRef<CreatedialogueComponent>, @Inject(MAT_DIALOG_DATA) public data) {
    this.resetSubstitution();
  }

  ngOnInit() {
    const minValue = 3;
    this.filteredMaterialFrom = this.materialFrom.valueChanges
      .debounceTime(300)
      .switchMap(value => {
        return (value !== null && value.length >= minValue) ? this.appData.get(this.appData.url.getMaterialCode, [this.formValues.Plant, value]) : [];
      }).map(res => this.materialCode = res);

    this.filteredMaterialTo = this.materialTo.valueChanges
      .debounceTime(300)
      .switchMap(value => {
        return (value !== null && value.length >= minValue) ? this.appData.get(this.appData.url.getMaterialCode, [this.formValues.Plant, value]) : [];
      }).map(res => this.materialCode = res);

  }

  public resetSubstitution() {
    this.formValues = cloneDeep(this.data.editdata);
    if (this.data.mode === dialogMode.edit) {
      this.plantControl.disable();
      this.materialFrom.setValue(this.formValues.MaterialFrom);
      this.materialTo.setValue(this.formValues.MaterialTo);
      this.getDateStatus(this.formValues.Plant);
    } else {
      this.formValues.Status = profileStatusType.yes;
      this.plantControl.reset();
      this.materialFrom.reset();
      this.materialTo.reset();
    }
  }

  public getDateStatus(plantId) {
    this.loading = true;
    const selectedPlant = filter(this.data.plants, function (currentObject) { return currentObject.PlantID === plantId; });
    selectedPlant[0].BusinessUnit === businessUnits.FLAV ? this.selectPlantOptions = this.Options.FLAV : this.selectPlantOptions = this.Options.FRAG;
    this.formValues.MaterialFrom = null;
    this.formValues.MaterialTo = null;
    this.loading = false;
  }

  public submitSubstitution(value) {
    this.loading = true;
    this.appData.post(this.appData.url.createSubstitution, [], value).subscribe((createResp) => {
      this.dialogRef.close(createResp === true ? dialogMode.Created : 'Create Substitution Unsuccess');
    }, (errResp) => {
      this.notification.warning(errResp.error.error.message);
      this.loading = false;
    });
  }

  public updateSubstitution(value) {
    this.loading = true;
    this.appData.put(this.appData.url.updateSubstitution, [], value).subscribe((updateResp) => {
      this.dialogRef.close(updateResp === true ? dialogMode.Created : 'Update Substitution Unsuccess');
    }, (errResp) => {
      this.dialogRef.close(errResp.error.message);
    });
  }

}
