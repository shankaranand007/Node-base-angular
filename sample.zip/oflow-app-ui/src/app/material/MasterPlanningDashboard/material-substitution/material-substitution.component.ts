import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { filter } from 'lodash';
import { MatDialog, MatSort, MatPaginator, MatTableDataSource, MatDialogConfig } from '@angular/material';
import { AppBroadCast } from '../../../_services';
import { AppData } from '../../../app.data';
import { businessUnits, dialogMode, profileStatusType, DialogContent, deleteDialogFlag } from '../../../_shared/interface/dialogEnum';
import { CreatedialogueComponent } from './createdialogue/createdialogue.component';
import { DeleteDialogComponent } from '../../../_shared/components/deletedialog/deletedialog.component';
import * as moment from 'moment';

@Component({
  selector: 'app-material-substitution',
  templateUrl: './material-substitution.component.html',
  styleUrls: ['./material-substitution.component.css']
})

export class MaterialSubstitutionComponent implements OnInit {
  public displayedColumns: string[];
  public plant: any;
  public searchType: boolean = false;
  public searchMFrom: boolean = false;
  public searchMTo: boolean = false;
  public loading: boolean = false;
  public dataSource: any;
  public substitutionCount: number = 0;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private notification: ToastrService, private appData: AppData, public dialog: MatDialog, private pubSub: AppBroadCast) {
  }

  ngOnInit() {
    this.getMaterialSubstitution();
    this.getPlant();
    this.pubSub.pubShowMenu('substitution');
  }

  public getPlant() {
    this.appData.get(this.appData.url.getPlant, []).subscribe((plant_data) => {
      this.plant = filter(plant_data, function (currentObject) { return currentObject.BusinessUnit === businessUnits.FLAV || currentObject.BusinessUnit === businessUnits.FRAG; });
    });
  }

  public openCreateUpdateDialog(modalMode, formData): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.disableClose = true;
    dialogConfig.width = DialogContent.widthMedium;
    dialogConfig.data = {
      mode: modalMode,
      plants: this.plant,
      editdata: formData
    };
    const DialogRef = this.dialog.open(CreatedialogueComponent, dialogConfig);
    DialogRef.afterClosed().subscribe(record => {
      if (!record) { return; }
      if (record === dialogMode.Created || record === dialogMode.Updated) {
        this.notification.success(`Material Substitution ${record} Successfully`);
        this.getMaterialSubstitution();
      } else {
        this.notification.warning(record);
      }
    });
  }

  public openConfirmationDialog(rootData): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = DialogContent.widthSmall;
    dialogConfig.data = {
      title: DialogContent.title,
      bodyMessage: DialogContent.desc,
      deleteItem: `PlantID: ${rootData.Plant} (${rootData.MaterialFrom} - ${rootData.MaterialTo}) `
    };
    const deleteDialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    deleteDialogRef.afterClosed().subscribe(record => {
      if (!record) { return; }
      if (record === deleteDialogFlag.yes) {
        this.deleteSubstitution(rootData);
      }
    });
  }

  private deleteSubstitution(data) {
    this.appData.delete(this.appData.url.deleteSubstitution, [data.Plant, data.MaterialFrom, data.MaterialTo]).subscribe((deleteResp) => {
      this.notification.success('Deleted Successfully');
      this.getMaterialSubstitution();
    }, (errResp) => {
      this.notification.error(errResp.error.message);
    });
  }

  public getMaterialSubstitution() {
    this.loading = true;
    this.displayedColumns = ['Plant', 'SubType', 'MaterialFrom', 'MaterialTo', 'Update', 'Enabled', 'Action'];
    this.appData.get(this.appData.url.getSubstitution, []).subscribe((substitutionData) => {
      this.substitutionCount = substitutionData.length;
      this.prepareForTable(substitutionData, ['SubType', 'MaterialFrom', 'MaterialTo']);
    });
  }

  public formatDate(dateValue) {
    return moment.utc(dateValue).format('MMM DD YYYY, hh:mm:ss A');
  }

  private prepareForTable(datasource, filterColumn) {
    const ELEMENT_DATA = datasource;
    this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    this.dataSource.filterPredicate = function (data, filterValue: string): boolean {
      return typeof filterColumn === 'string' ? data[filterColumn].toLowerCase().includes(filterValue) :
        data[filterColumn[0]].toLowerCase().includes(filterValue) || data[filterColumn[1]].toLowerCase().includes(filterValue) || data[filterColumn[2]].toLowerCase().includes(filterValue);
    };
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.loading = false;
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public updateSubstitutionStatus(data, profileStatus) {
    this.loading = true;
    data.Status = profileStatus ? profileStatusType.yes : profileStatusType.no;
    this.appData.put(this.appData.url.updateSubstitution, [], data).subscribe((updateResp) => {
      this.notification.success(`${data.SubType} status updated successfully`);
      this.getMaterialSubstitution();
    }, (errResp) => {
      this.loading = false;
      this.notification.error(errResp.error.message);
    });
  }
}
