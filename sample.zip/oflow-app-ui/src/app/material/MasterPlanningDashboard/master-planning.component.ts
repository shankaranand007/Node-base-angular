import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppBroadCast } from '../../_services';


@Component({
  selector: 'app-master-planning',
  templateUrl: './master-planning.component.html',
  styleUrls: ['./master-planning.component.css']
})
export class MasterPlanningComponent implements OnInit {
  public userInfo: string = '';
  public isDraweropen: boolean = false;
  public isDrawernavopen: boolean = false;
  public searchShow: boolean = false;
  public activeSubMenu: any;

  constructor(private router: Router, private pubSub: AppBroadCast) { }

  ngOnInit() {
    this.pubSub.showSubmenu.subscribe((data) => {
      this.activeSubMenu = data;
    });
  }

  public navigateRouter(params: string) {
    this.router.navigate([params]);
  }

  public draweropen() {
    this.isDraweropen = !this.isDraweropen;
  }
  public drawernavopen() {
    this.isDrawernavopen = !this.isDrawernavopen;
  }

  public toggleSearch() {
    this.searchShow ? this.searchShow = false : this.searchShow = true;
  }

}
