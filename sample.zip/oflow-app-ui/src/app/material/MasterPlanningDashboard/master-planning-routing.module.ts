import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../_shared/okta/auth.guard';
import { MasterPlanningComponent } from './master-planning.component';
import { MaterialSubstitutionComponent } from './material-substitution/material-substitution.component';

const MasterPlanningRouting: Routes = [{
    path: 'material/master',
    component: MasterPlanningComponent,
    children: [
        { path: '', redirectTo: 'substitution', pathMatch: 'full' },
        { path: 'substitution', component: MaterialSubstitutionComponent, canActivate: [AuthGuard] },
        {path: '**', redirectTo: 'substitution'}
    ]
}];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(MasterPlanningRouting)
    ],
    exports: [RouterModule],
    declarations: [],
    providers: [AuthGuard],
})
export class MasterPlanningRoutingModule { }
