import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MasterPlanningComponent } from './master-planning.component';
import { AuthGuard } from '../../_shared/okta/auth.guard';
import { NgMaterialModule } from '../../material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from '../../_shared/components/share.module';
import { ToastrModule } from 'ngx-toastr';

import { CreatedialogueComponent } from './material-substitution/createdialogue/createdialogue.component';
import { MaterialSubstitutionComponent } from './material-substitution/material-substitution.component';
import { MasterPlanningRoutingModule } from './master-planning-routing.module';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        MasterPlanningRoutingModule,
        FormsModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        NgMaterialModule,
        ToastrModule.forRoot()
    ],
    declarations: [
        MasterPlanningComponent,
        MaterialSubstitutionComponent,
        CreatedialogueComponent
    ],
    providers: [AuthGuard],
    entryComponents: [
        CreatedialogueComponent
    ],
})
export class MasterPlanningModule { }
