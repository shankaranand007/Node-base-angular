import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterPlanningComponent } from './master-planning.component';

describe('MasterPlanningComponent', () => {
  let component: MasterPlanningComponent;
  let fixture: ComponentFixture<MasterPlanningComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterPlanningComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterPlanningComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
