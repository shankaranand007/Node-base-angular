import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { OAuthService } from 'angular-oauth2-oidc-cache';
import { AppState } from '../../_services';
import { profileType } from '../../_shared/interface/dialogEnum';
import { concat } from 'rxjs/operators/concat';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private oAuthSvc: OAuthService, private router: Router, private appState: AppState) { }

    public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        if (this.oAuthSvc.hasValidIdToken() && this.oAuthSvc.hasValidAccessToken()) {
            const userinfo = this.appState.get(this.appState.stateId.userInfo);
            return route.routeConfig.path.indexOf(profileType.admin) === -1 ? true : userinfo.IsAdmin === 'Y' ? true : false;
        } else {
            this.oAuthSvc.initImplicitFlow();
            return false;
        }
    }

    public canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        if (this.oAuthSvc.hasValidIdToken() && this.oAuthSvc.hasValidAccessToken()) {
            return true;
        } else {
            this.oAuthSvc.initImplicitFlow();
            return false;
        }
    }
}
