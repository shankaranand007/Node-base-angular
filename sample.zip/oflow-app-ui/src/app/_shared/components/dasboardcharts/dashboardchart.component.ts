import { Component, OnInit, Input } from '@angular/core';
import { AppState } from '../../../_services';
import { AppData } from '../../../app.data';
import { NGXLogger } from 'ngx-logger';
import { NgxChartsModule } from '@swimlane/ngx-charts';

enum ChartType {
    VerticalBarChart = 1,
    PieGridChart = 2,
    LineChart = 3,
    PieChart = 4
}

@Component({
    selector: 'dashboard-charts',
    templateUrl: './dashboardchart.component.html',
    styleUrls: ['./dashboardchart.component.scss']
})

export class DashboardChartComponent implements OnInit {
    public userInfo: any;
    public view: any[] = [680, 250];
    public colorScheme = { domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA'] };
    @Input() showXAxis: boolean = true;
    @Input() showYAxis: boolean = true;
    @Input() gradient: boolean = false;
    @Input() showLegend: boolean = true;
    @Input() showXAxisLabel: boolean = true;
    @Input() showYAxisLabel: boolean = true;
    @Input() showLabels: boolean = true;
    @Input() explodeSlices: boolean = true;
    @Input() doughnut: boolean = true;
    @Input() autoScale: boolean = true;
    @Input() roundDomains: boolean = true;
    @Input() type: ChartType;
    @Input() data: any;
    @Input() chartTitle: string = '';
    @Input() yAxisLabel: string = '';
    @Input() xAxisLabel: string = '';

    public ngOnInit() {
        // this.logger.log('Logging info');
        // this.logger.info('logging info');
    }
}
