import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DashboardChartComponent } from './dashboardchart.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { NgMaterialModule } from '../../../material.module';

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		NgxChartsModule,
		NgMaterialModule
	],
	declarations: [ DashboardChartComponent ],
	providers: [],
	exports: [DashboardChartComponent]
	// schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ChartsModule { }
