import { Component, Input, OnInit } from '@angular/core';
import { AppState } from '../../_services';
import { AppData } from '../../app.data';
import { NGXLogger } from 'ngx-logger';

@Component({
    selector: 'app-greetuser',
    template: `<span>{{msg}}</span>`
})

export class AppGreetUserComponent implements OnInit {
    public msg: string = 'Loading...';


    constructor(private appState: AppState, private appData: AppData, private logger: NGXLogger) {
    }

    public ngOnInit() {
        const thehours = new Date().getHours();
        const morning = ('Good Morning');
        const afternoon = ('Good Afternoon');
        const evening = ('Good Evening');

        if (thehours >= 0 && thehours < 12) {
            this.msg = morning;

        } else if (thehours >= 12 && thehours < 17) {
            this.msg = afternoon;

        } else if (thehours >= 17 && thehours < 24) {
            this.msg = evening;
        }
    }

}
