import { Component } from '@angular/core';

@Component({
  selector: 'no-content',
  template: `
        <div style=" padding: 1em;text-align:center;padding-top:3%">
            <div>
                <img src="../../assets/img/404_nf.png" alt="Page Not Found">
            </div>
        </div>`
})
export class NoContentComponent {

}
