import { Component, Input } from '@angular/core';

@Component({
    selector: 'spinner-component',
    template: `<div *ngIf="spinnerShow" class="sc-background"></div><div *ngIf="spinnerShow" class="sc-default-spinner sc-center"></div>`
})
export class SpinnerComponent {
    @Input() public spinnerShow: boolean;
}
