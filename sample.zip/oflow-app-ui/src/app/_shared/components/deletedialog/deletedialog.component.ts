import { Component, OnInit, Inject, HostListener } from '@angular/core';
import { AppData } from '../../../app.data';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { deleteDialogFlag } from '../../interface/dialogEnum';

@Component({
  selector: 'app-deletedialog',
  templateUrl: './deletedialog.component.html',
  styleUrls: ['./deletedialog.component.css']
})

export class DeleteDialogComponent {
  constructor(private appData: AppData, public dialogRef: MatDialogRef<DeleteDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data, private notification: ToastrService) {
  }

  @HostListener('window:keyup.esc') onKeyUp() {
    this.dialogRef.close();
  }

}

