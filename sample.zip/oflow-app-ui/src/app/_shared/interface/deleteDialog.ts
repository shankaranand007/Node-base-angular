export interface DialogInterface{
  
}