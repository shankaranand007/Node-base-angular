export enum dialogMode {
  create = 'Create',
  edit = 'Edit',
  update = 'Update',
  delete = 'Delete',
  Created = 'Created',
  Updated = 'Updated',
  multiple = 'multiple',
  single = 'single',
}

export enum deleteDialogFlag {
  yes = 'yes',
  no = 'no'
}

export enum DialogContent {
  title = 'Confirmation',
  desc = 'Are you sure to delete this item?',
  widthLarge = '1090px',
  widthSmall = '410px',
  widthMedium = '450px'
}

export enum profileStatusType {
  yes = 'Y',
  no = 'N',
  delete = 'D'
}

export enum businessUnits {
  FLAV = 'FLAV',
  FRAG = 'FRAG',
  FI = 'FI',
  MRPS = 'MRPS',
  SALESGRP = 'SALESGRP',
  PlantID = 'PlantID',
  ID = 'ID'
}

export enum profileType {
  user = 'user',
  admin = 'admin',
  global = 'Global',
  personal = 'Personal'
}

export enum noHeaderValues {
  materialMaterialDetail = '/material/rmp/materialdetail',
}
