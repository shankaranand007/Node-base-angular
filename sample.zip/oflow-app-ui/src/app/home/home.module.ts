import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home.component';
import { AuthGuard } from '../_shared/okta/auth.guard';
import { AppGreetUserComponent } from '../_shared/components/greetuser.component';
import { ChartsModule } from '../_shared/components/dasboardcharts/dashboardchart.module';
import { NgMaterialModule } from '../material.module';

const HomeRouting: ModuleWithProviders = RouterModule.forChild([
	{
		path: 'home',
		component: HomeComponent,
		canActivate: [AuthGuard]
	}
]);

@NgModule({
	imports: [
		CommonModule,
		HomeRouting,
		FormsModule, // ToastrModule added
		ChartsModule,
		NgMaterialModule
	],
	declarations: [HomeComponent, AppGreetUserComponent],
	providers: []
	// schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class HomeModule { }
