import { Component, OnInit } from '@angular/core';
import { AppState } from '../_services';
import { AppData } from '../app.data';
import { NGXLogger } from 'ngx-logger';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public userInfo: any;
  public isDraweropen = false;

  public department = [
    { name: 'Business Unit', value: 40632 },
    { name: 'Sales & Marketing', value: 49737 },
    { name: 'Products & Projects', value: 36745 }
  ];
  public busUnits = [
    { 'name': 'Unit 1', 'value': 8940000 },
    { 'name': 'Unit 2', 'value': 5000000 },
    { 'name': 'Unit 3', 'value': 7200000 }
  ];
  public lineChartsData = [{ 'name': '1RR04333', 'series': [{ 'name': '2010', 'value': 732 }, { 'name': '2011', 'value': 894 }, { 'name': '2012', 'value': 652 }, { 'name': '2013', 'value': 692 }] }, { 'name': '14577652', 'series': [{ 'name': '2010', 'value': 448 }, { 'name': '2011', 'value': 672 }, { 'name': '2012', 'value': 574 }, { 'name': '2013', 'value': 755 }] }];

  public view: any[] = [];
  public colorScheme = { domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA'] };

  public regionXaxisLabel = 'Year';
  public regionYaxisLabel = 'Sales In Units';

  constructor(private appState: AppState, private appData: AppData, private logger: NGXLogger) {
    this.userInfo = this.appState.get('USER_INFO');
  }
  public ngOnInit() {
    // this.logger.log('Logging info');
    // this.logger.info('logging info');
  }
}

