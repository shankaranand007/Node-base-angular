
import { Angulartics2Piwik } from 'angulartics2/piwik';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AppState } from './_services';
import { AppData } from './app.data';
import { groupBy, filter, includes, forEach, chain, findIndex, fromPairs, zip, cloneDeep, reduceRight } from 'lodash';
import { Observable } from 'rxjs/Observable';
import { ToastrService } from 'ngx-toastr';
import { INTERNAL_BROWSER_DYNAMIC_PLATFORM_PROVIDERS } from '@angular/platform-browser-dynamic/src/platform_providers';
import { noHeaderValues } from './_shared/interface/dialogEnum';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public userInfo: any = '';
  public title = 'oFlow';
  public currentUser: any;
  public userPhotoUrl: string = '';
  public profileList: any = [];
  public prepareJSON = {
    FLAV: new Array(),
    FRAG: new Array(),
    FI: new Array()
  };
  public noHeader: boolean = false;
  public defaultProfile: any = [];
  public defaultProfileHeading: string;
  public loading: boolean = false;
  public showTooltip: boolean = false;

  constructor(
    private router: Router,
    private appState: AppState,
    private appData: AppData,
    private angulartics2Piwik: Angulartics2Piwik,
    private notification: ToastrService
  ) {
    this.loading = true;
    this.initMatomo();
  }

  public ngOnInit() {

    if (this.appState.get(this.appState.stateId.isAccessDenied)) {
      this.userInfo = { DisplayName: '' };
      this.loading = false;
      this.defaultProfile.push(this.userInfo);
      this.router.navigate(['/unauthorized']);
    } else {
      this.noHeader = includes(window.location.pathname, noHeaderValues.materialMaterialDetail);
      this.getDefaultProfile();
      this.getParticularUserProfile();
      this.getGobalProfile();
      this.userInfo = this.appState.get('USER_INFO');
      this.getProfilePhoto(this.userInfo.Id);
    }
  }

  private initMatomo() {
    const user = this.appState.getCurrentUser() ? this.appState.getCurrentUser() : null;
    let userId;
    if (user) {
      userId = `${user.Id} - ${user.DisplayName}`;
    } else {
      userId = 'Anonymous';
    }
    this.angulartics2Piwik.setUsername(userId);
  }

  public navigateRouter(params: string) {
    this.router.navigated = true;
    this.router.navigate([params]);
  }

  private getProfilePhoto(userId) {
    this.userPhotoUrl = this.appData.getImageUrl(this.appData.url.userPhoto, [userId]);
  }

  private getParticularUserProfile() {
    this.appData.get(this.appData.url.getParticularUserProfile, [this.userInfo.Id]).subscribe((profileInfo) => {
      this.profileList = profileInfo;
    });
  }

  private getDefaultProfile() {
    this.userInfo = this.appState.get(this.appState.stateId.userInfo);
    this.appData.get(this.appData.url.getDefaultProfile, [this.userInfo.Id]).subscribe((defaultProfile) => {
      this.defaultProfile = defaultProfile;
      this.loading = false;
      if (defaultProfile.length > 0) {
        this.defaultProfileHeading = defaultProfile[0].Type === 'U' ? defaultProfile[0].Name : defaultProfile[0].Name;
        this.setAppState(defaultProfile[0].Info, this.defaultProfileHeading);
      }
    });
  }

  private setAppState(profileInfo, profileName) {
    profileInfo = typeof profileInfo === 'string' ? JSON.parse(profileInfo) : profileInfo;
    this.appState.set(this.appState.stateId.defaultProfileInfo, profileInfo);
    this.appState.set(this.appState.stateId.defaultProfileName, profileName);
  }

  private getGobalProfile() {
    const region = 'Region';
    this.appData.get(this.appData.url.getGlobalProfile, []).subscribe((globalprofileInfo) => {
      const typeGroup = groupBy(cloneDeep(globalprofileInfo), 'Type');
      const preparedData = { FLAV: new Array(), FRAG: new Array(), FI: new Array() };
      forEach(typeGroup, function (value, key) {
        const result = chain(value).groupBy(region).toPairs().map(function (currentItem) {
          return fromPairs(zip([region, 'Plants'], currentItem));
        }).value();
        preparedData[key] = result;
      });
      this.prepareJSON = preparedData;
    });
  }

  public getTooltipInfo(info) {
    const profileInfo = typeof info === 'string' ? JSON.parse(info) : info;
    const plants = reduceRight([profileInfo.FLAV, profileInfo.FRAG, profileInfo.FI], function (flattened, other) { return flattened.concat(other); }, []);
    const plantList = plants.map(data => data.PlantID);
    const mrpc = profileInfo.MRPS.map(data => data.ID);
    const sales = profileInfo.SALESGRP.map(data => data.ID);
    return 'Plants:' + plantList.toString() + ' MRPC:' + mrpc.toString() + ' SalesGrp:' + sales.toString();
  }

  public setDefaultProfile(data) {
    this.loading = true;
    const prepareForUpdate = {
      ID: this.userInfo.Id,
      Name: this.userInfo.DisplayName,
      DefaultProfileID: data.ID,
      CreatedBy: this.userInfo.Id,
      UpdatedBy: this.userInfo.Id
    };
    const services = [];
    this.defaultProfile.length === 0 ? services.push(this.appData.post(this.appData.url.createUser, [], prepareForUpdate)) : services.push(this.appData.put(this.appData.url.setDefaultProfile, [], prepareForUpdate));
    Observable.forkJoin(services).subscribe(t => {
      this.notification.success(data.Name + ' assigned as default profile successfully');
      this.defaultProfileHeading = data.Type === 'U' ? data.Name : data.Name;
      this.loading = false;
      this.setAppState(data.Info, this.defaultProfileHeading);
      this.getDefaultProfile();
    }, errResp => {
      this.notification.error(errResp.error.message);
      this.loading = false;
    });
  }
}
