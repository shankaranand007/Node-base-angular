import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgMaterialModule } from '../material.module';
import { DatePipe } from '@angular/common';
import { AuthGuard } from '../_shared/okta/auth.guard';
import { ToastrModule } from 'ngx-toastr';
import { SharedModule } from '../_shared/components/share.module';
import { CreateDialogComponent } from './factoryCalendar/createCalendarDialog/createdialog.component';
import { FactoryCalendarComponent } from './factoryCalendar/factorycalendar.component';
import { ProfileComponent } from './profile/profile.component';
import { CreateProfileDialogComponent } from './profile/createProfileDialog/create-profile-dialog.component';
import { PrivilegeComponent } from './privilege/privilege.component';

const adminRouting: ModuleWithProviders = RouterModule.forChild([
	{
		path: 'admin/factorycalendar',
		component: FactoryCalendarComponent,
		canActivate: [AuthGuard]
	}, {
		path: 'admin/profile/:profile',
		component: ProfileComponent,
		canActivate: [AuthGuard]
	}
]);

@NgModule({
	imports: [
		CommonModule,
		adminRouting,
		BrowserAnimationsModule,
		NgMaterialModule,
		ReactiveFormsModule,
		FormsModule,
		SharedModule,
		ToastrModule.forRoot() // ToastrModule added
	],
	declarations: [
		FactoryCalendarComponent,
		CreateDialogComponent,
		ProfileComponent,
		CreateProfileDialogComponent,
		PrivilegeComponent
	],
	entryComponents: [
		CreateDialogComponent,
		CreateProfileDialogComponent
	],
	providers: [DatePipe]
})
export class AdminModule { }
