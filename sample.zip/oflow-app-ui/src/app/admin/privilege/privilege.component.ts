import { Component, OnInit, ViewChild } from '@angular/core';
import { AppData } from '../../app.data';
import { MatDialog, MatSort, MatPaginator, MatTableDataSource, MatDialogConfig } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { profileStatusType } from '../../_shared/interface/dialogEnum';

@Component({
  selector: 'app-privilege',
  templateUrl: './privilege.component.html',
  styleUrls: ['./privilege.component.css']
})
export class PrivilegeComponent implements OnInit {
  public columnList: string[];
  public dataSource: any;
  public loading: boolean = false;
  public searchName: boolean = false;
  public searchPlant: boolean = false;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private appData: AppData, public dialog: MatDialog, private notification: ToastrService) { }


  ngOnInit() {
    this.getAllUser();
  }

  private getAllUser() {
    this.loading = true;
    this.columnList = ['ID', 'Name', 'DefaultProfile', 'LastLogin', 'IsAdmin'];
    this.appData.get(this.appData.url.getAllUser, []).subscribe((userprofileInfo) => {
      this.prepareForTable(userprofileInfo, ['Name', 'DefaultProfile']);
    }, (errResp) => {
      this.loading = false;
      this.notification.error(errResp.error.message);
    });
  }

  private prepareForTable(datasource, filterColumn) {
    const ELEMENT_DATA = datasource;
    this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      return typeof filterColumn === 'string' ? data[filterColumn].toLowerCase().includes(filter) :
        data[filterColumn[0]].toLowerCase().includes(filter) || data[filterColumn[1]].toLowerCase().includes(filter);
    };
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.loading = false;
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public updateProfileStatus(data, status) {
    this.loading = true;
    data.IsAdmin = status ? profileStatusType.yes : profileStatusType.no;
    this.appData.put(this.appData.url.updateAdminprivilege, [data.ID], data).subscribe((updateResp) => {
      this.notification.success(`${data.Name} privilege updated successfully`);
      this.getAllUser();
    }, (errResp) => {
      this.loading = false;
      this.notification.error(errResp.error.message);
    });
  }
}
