import { Component, OnInit, ViewChild } from '@angular/core';
import { AppState } from '../../_services';
import { AppData } from '../../app.data';
import { MatDialog, MatSort, MatPaginator, MatTableDataSource, MatDialogConfig } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CreateProfileDialogComponent } from './createProfileDialog/create-profile-dialog.component';
import { DeleteDialogComponent } from '../../_shared/components/deletedialog/deletedialog.component';
import { DialogContent, deleteDialogFlag, dialogMode, profileType, profileStatusType } from '../../_shared/interface/dialogEnum';


@Component({
  selector: 'app-admin-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})

export class ProfileComponent implements OnInit {
  public columnList: string[];
  public loading: boolean = false;
  public searchShow: boolean = false;
  public dataSource: any;
  public plants: any = [];
  public profileType: string;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private appData: AppData, public dialog: MatDialog, private route: ActivatedRoute, private notification: ToastrService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.profileType = params['profile'];
      this.searchShow = false;
      this.getUserListByType();
    });
    this.getPlant();
  }

  private getUserListByType() {
    const global = 'global';
    this.profileType === profileType.user ? this.getProfileList() : this.profileType === global ? this.getGlobalProfile() : this.getProfileList();
  }

  public getProfileList() {
    this.loading = true;
    this.columnList = ['UserID', 'Name', 'CreatedBy', 'Status', 'Action'];
    this.appData.get(this.appData.url.getUserProfile, []).subscribe((userprofileInfo) => {
      this.prepareForTable(userprofileInfo, ['UserID', 'UserName']);
    });
  }

  public getGlobalProfile() {
    this.loading = true;
    this.columnList = ['Name', 'Region', 'Type', 'Status', 'Action'];
    this.appData.get(this.appData.url.getGlobalProfile, []).subscribe((globalprofileInfo) => {
      this.prepareForTable(globalprofileInfo, 'Name');
    }, (errResp) => {
      this.notification.error(errResp.error.message);
      this.loading = false;
    });
  }

  private prepareForTable(datasource, filterColumn) {
    const ELEMENT_DATA = datasource;
    this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      return typeof filterColumn === 'string' ? data[filterColumn].toLowerCase().includes(filter) :
        data[filterColumn[0]].toLowerCase().includes(filter) || data[filterColumn[1]].toLowerCase().includes(filter);
    };
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.loading = false;
  }

  public getPlant() {
    this.appData.get(this.appData.url.getPlant, []).subscribe((plant_data) => {
      this.plants = plant_data;
    });
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public openCreateUpdateDialog(profileMode, formData): void {
    const createDialogRef = this.dialog.open(CreateProfileDialogComponent, {
      disableClose: true,
      width: DialogContent.widthLarge,
      data: {
        plantList: this.plants,
        mode: profileMode,
        profileType: this.profileType === profileType.user ? profileType.personal : profileType.global,
        editdata: formData
      }
    });

    createDialogRef.afterClosed().subscribe(record => {
      if (!record) { return; }
      if (record === dialogMode.Created || record === dialogMode.Updated) {
        this.notification.success(`Profile ${record} Successfully`);
        this.getUserListByType();
      } else {
        this.notification.warning(record);
      }
    });
  }

  public openConfirmationDialog(rootData): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = DialogContent.widthSmall;
    dialogConfig.data = {
      title: DialogContent.title,
      bodyMessage: DialogContent.desc,
      deleteItem: `${rootData.UserName} (${rootData.UserID}) - ${rootData.Name}`
    };
    const deleteDialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    deleteDialogRef.afterClosed().subscribe(record => {
      if (!record) { return; }
      if (record === deleteDialogFlag.yes) {
        this.deleteProfile(rootData);
      }
    });
  }

  private deleteProfile(data) {
    this.appData.delete(this.appData.url.deleteProfile, [data.ID]).subscribe((deleteResp) => {
      this.notification.success('Deleted Successfully');
      this.getUserListByType();
    }, (errResp) => {
      this.notification.error(errResp.error.message);
    });
  }

  public updateProfileStatus(data, profileStatus) {
    this.loading = true;
    data.Status = profileStatus ? profileStatusType.yes : profileStatusType.no;
    this.appData.put(this.appData.url.updateProfileStatus, [], data).subscribe((updateResp) => {
      this.notification.success(`${data.Name} status updated successfully`);
      this.getUserListByType();
    }, (errResp) => {
      this.loading = false;
      this.notification.error(errResp.error.message);
    });
  }

}
