import { Component, OnInit, Inject } from '@angular/core';
import { AppData } from '../../../app.data';
import { AppState } from '../../../_services';
import { businessUnits, dialogMode, profileType, profileStatusType } from '../../../_shared/interface/dialogEnum';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, Validators } from '@angular/forms';
import { groupBy, filter, reduceRight, forEach, chain, findIndex, fromPairs, zip, cloneDeep, remove } from 'lodash';
import { IProfile } from 'oflow.entities';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-create-profile-dialog',
  templateUrl: './create-profile-dialog.component.html',
  styleUrls: ['./create-profile-dialog.component.css']
})

export class CreateProfileDialogComponent implements OnInit {
  public formValues: IProfile;
  public plantList: any;
  public plantGroup: any;
  public prepareJSON = { FLAV: new Array(), FRAG: new Array(), FI: new Array(), MRPS: new Array(), SALESGRP: new Array() };
  public userProfileCount: number = 5;
  public loading: boolean = false;
  public searchCtrl = new FormControl('', [Validators.required]);
  public profileNameCtrl = new FormControl('', [Validators.required]);
  public filteredData: Observable<any[]>;
  private myContent: any[] = [];
  public MRPC: any[] = [];
  public SalesGroup: any[] = [];
  public getMRPCandSG: string[] = [];
  public loadingSpinner = { MRPCandSales: false, filterUser: false };

  constructor(private appState: AppState, private appData: AppData, public dialogRef: MatDialogRef<CreateProfileDialogComponent>, @Inject(MAT_DIALOG_DATA) public data) {
    this.resetProfile();
    this.plantGroup = groupBy(cloneDeep(data.plantList), 'BusinessUnit');
    this.prepareData(this.plantGroup);
  }

  ngOnInit() {
    const minValue = 3;
    this.filteredData = this.searchCtrl.valueChanges
      .debounceTime(500)
      .switchMap(value => {
        return (value !== null && value.length >= minValue) ? this.appData.get(this.appData.url.searchUserByName, [value]) : [];
      }).map(res => this.myContent = res);
  }

  public resetProfile() {
    this.formValues = cloneDeep(this.data.editdata);
    if (this.data.mode === dialogMode.edit && this.data.profileType === profileType.personal) {
      this.appData.get(this.appData.url.searchUserByName, [this.formValues.UserID]).subscribe((response) => {
        this.searchCtrl.setValue(response[0].DisplayName);
      });
      this.prepareJSON = cloneDeep(this.data.editdata.Info);
      this.getPlantsMRPCandSalesGrp();
      this.searchCtrl.disable();
    } else if (this.data.mode === dialogMode.create && this.data.profileType === profileType.personal) {
      this.formValues.Status = profileStatusType.yes;
      this.searchCtrl.reset();
      this.profileNameCtrl.reset();
      this.prepareJSON = { FLAV: [], FRAG: [], FI: [], MRPS: [], SALESGRP: [] };
    } else if (this.data.profileType === profileType.global) {
      this.prepareJSON = cloneDeep(this.data.editdata.Info);
      this.getPlantsMRPCandSalesGrp();
    }
  }

  public checkProfileCount(selectedUserId) {
    this.loadingSpinner.filterUser = true;
    this.appData.get(this.appData.url.getParticularUserProfile, [selectedUserId]).subscribe((profileInfo) => {
      this.userProfileCount = profileInfo.length;
      this.loadingSpinner.filterUser = false;
    });
  }

  private prepareData(data) {
    const groupData = [];
    forEach(data, function (value, key) {
      const result = chain(value).groupBy('GeoLocation').toPairs().map(function (currentItem) {
        return fromPairs(zip(['GeoLocation', 'Plants'], currentItem));
      }).value();
      groupData.push({ businessUnits: key, businessGroup: result });
    });
    this.plantList = groupData;
  }

  public setSelectedPlant(event, selectedPlantID, businessUnitType) {
    event.checked ? this.prepareJSON[businessUnitType].push({ PlantID: selectedPlantID }) : remove(this.prepareJSON[businessUnitType], { PlantID: selectedPlantID });
    this.getPlantsMRPCandSalesGrp();
  }

  public setSelectedMPRCandSALES(event, selectedValue, keyName) {
    event.checked ? this.prepareJSON[keyName].push({ ID: selectedValue }) : remove(this.prepareJSON[keyName], { ID: selectedValue });
  }

  public checkPlantStatus(plantId, label) {
    return (label === businessUnits.MRPS || label === businessUnits.SALESGRP) ? findIndex(this.prepareJSON[label], [businessUnits.ID, plantId]) === -1 ? false : true :
      findIndex(this.prepareJSON[label], [businessUnits.PlantID, plantId]) === -1 ? false : true;
  }

  public getIndexOfBusinessUint(data) {
    return findIndex(this.plantList, ['businessUnits', data]);
  }

  public selectAll(eventData, label) {
    const preparedData = [];
    const selectPlant = filter(this.data.plantList, function (element) { return element.BusinessUnit === label; });
    if (eventData.checked) {
      forEach(selectPlant, function (value) { preparedData.push({ PlantID: value.PlantID }); });
      this.prepareJSON[label] = preparedData;
    } else {
      this.prepareJSON[label] = new Array();
    }
    this.getPlantsMRPCandSalesGrp();
  }

  public selectAllMRPCandSales(eventData, rootData, label, insertKeyName) {
    const preparedData = [];
    if (eventData.checked) {
      forEach(rootData, function (value) { preparedData.push({ ID: value[insertKeyName] }); });
      this.prepareJSON[label] = preparedData;
    } else {
      this.prepareJSON[label] = new Array();
    }
  }

  private getPlantsMRPCandSalesGrp() {
    this.loadingSpinner.MRPCandSales = true;
    const result = reduceRight([this.prepareJSON.FLAV, this.prepareJSON.FRAG, this.prepareJSON.FI], function (flattened, other) { return flattened.concat(other); }, []);
    this.getMRPCandSG = result.map(data => data.PlantID);
    const services = [];
    services.push(this.appData.post(this.appData.url.getMrps, [], this.getMRPCandSG));
    services.push(this.appData.post(this.appData.url.getSiteGroup, [], this.getMRPCandSG));
    Observable.forkJoin(services).subscribe(response => {
      this.MRPC = response[0]; this.SalesGroup = response[1];
      this.loadingSpinner.MRPCandSales = false;
    }, error => {
      this.MRPC = []; this.SalesGroup = [];
      this.loadingSpinner.MRPCandSales = false;
    });
  }

  public submitProfile(saveData) {
    this.loading = true;
    this.formValues.Info = this.data.profileType === profileType.personal ? saveData : this.formValues.Info;
    if (this.data.mode === dialogMode.create && this.userProfileCount < 5) {
      this.formValues.CreatedBy = this.appState.get(this.appState.stateId.userInfo).Id;
      this.formValues.Type = this.data.profileType === profileType.personal ? 'U' : this.formValues.Type;
      this.appData.post(this.appData.url.createProfile, [], this.formValues).subscribe((response) => {
        this.dialogRef.close(response === true ? dialogMode.Created : 'Create Profile Unsuccess');
      }, (errResp) => {
        this.loading = false;
        this.dialogRef.close(errResp.error.message);
      });
    } else {
      this.formValues.UpdatedBy = this.appState.get(this.appState.stateId.userInfo).Id;
      this.appData.put(this.appData.url.updateProfile, [], this.formValues).subscribe((response) => {
        this.dialogRef.close(response === true ? dialogMode.Updated : 'Update Profile Unsuccess');
      }, (errResp) => {
        this.loading = false;
        this.dialogRef.close(errResp.error.message);
      });
    }
  }
}
