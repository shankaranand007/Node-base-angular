import { Component, OnInit, Inject } from '@angular/core';
import { AppState } from '../../../_services';
import { dialogMode } from '../../../_shared/interface/dialogEnum';
import { AppData } from '../../../app.data';
import { NGXLogger } from 'ngx-logger';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { filter, includes, reduceRight, cloneDeep } from 'lodash';
import { DatePipe } from '@angular/common';
import { FormControl, Validators } from '@angular/forms';
import { IDepartment, IFactoryCalendarOverride, IPlant } from 'oflow.entities';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';

@Component({
  selector: 'app-createdialog',
  templateUrl: './createdialog.component.html',
  styleUrls: ['./createdialog.component.css']
})

export class CreateDialogComponent {
  public minDate: any = new Date();
  public maxDate: any = new Date();
  public AllBusinessUnits: any = [
    { Code: 'FRAG', Description: 'Apply to All FR', Value: false },
    { Code: 'FLAV', Description: 'Apply to All FL', Value: false },
    { Code: 'FI', Description: 'Apply to All FRI', Value: false }
  ];

  public holidayStatus: string = '';
  public calendarDate: any = new Date();
  public dayIndicators: any[];
  public departments: IDepartment[];
  public plants: IPlant[];
  public factoryCalendar: IFactoryCalendarOverride[] = [];
  public formValues: any;
  public businessUnit: any[];
  public calendar = new FormControl('', [Validators.required]);
  public plantControl = new FormControl('', [Validators.required]);
  public loading: boolean = false;
  public spinner: boolean = false;

  constructor(private appState: AppState, private appData: AppData, private datePipe: DatePipe, private logger: NGXLogger, public dialogRef: MatDialogRef<CreateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data) {
    this.departments = data.department;
    this.plants = data.plant;
    this.dayIndicators = data.selectOption;
    this.formValues = cloneDeep(data.editdata);
    this.maxDate.setDate(this.maxDate.getDate() + 730);
    data.mode === dialogMode.create ? this.minDate.setDate(this.minDate.getDate() - 2) : this.minDate.setDate(new Date(this.formValues.OverrideDate));
  }

  public plantValidation() {
    filter(this.AllBusinessUnits, function (items) { return items.Value === true; }).length > 0 ?
      this.plantControl.clearValidators() :
      this.plantControl.setValidators([Validators.required]);
    this.plantControl.updateValueAndValidity();
  }

  public resetCalendar() {
    this.formValues = cloneDeep(this.data.editdata);
    this.AllBusinessUnits.forEach(item => { item.Value = false; });
    this.plantValidation();
  }

  private prepareForSave(plantstack: IPlant[]) {
    this.factoryCalendar = [];
    const deleteServiceStack: any[] = [];
    for (const curPlant of plantstack) {
      for (const dept of this.departments) {
        if (typeof this.formValues[dept.DepartmentName] !== 'undefined' && this.formValues[dept.DepartmentName] !== null && this.formValues[dept.DepartmentName] !== 'null') {
          const factoryCal: IFactoryCalendarOverride = {
            PlantID: curPlant.PlantID,
            OverrideDate: new Date(this.datePipe.transform(this.formValues.OverrideDate, 'yyyy-MM-dd')),
            DepartmentCode: dept.DepartmentCode,
            DayIndicator: this.formValues[dept.DepartmentName],
            IsActive: 'Y',
            CreatedBy: this.appState.get(this.appState.stateId.userInfo).Id,
            UpdatedBy: this.appState.get(this.appState.stateId.userInfo).Id
          };
          this.factoryCalendar.push(factoryCal);
        } else {
          deleteServiceStack.push(this.appData.delete(this.appData.url.singleDelete, [curPlant.PlantID, this.formValues.OverrideDate, dept.DepartmentCode]));
        }
      }
    }
    this.submitFormData(this.factoryCalendar, deleteServiceStack);
  }

  public submitCalendar() {
    let selectedPlants: IPlant[] = [];
    const values = this.formValues;
    for (const units of this.AllBusinessUnits) {
      if (units.Value === true) {
        selectedPlants.push(filter(this.plants, function (items) { return includes(items.BusinessUnit, units.Code); }));
      }
    }
    selectedPlants = selectedPlants.length > 0 ?
      reduceRight(selectedPlants, function (flattened, other) { return flattened.concat(other); }, []) :
      filter(this.plants, function (items) { return items.PlantID === values.PlantID; });

    this.prepareForSave(selectedPlants);
  }

  private submitFormData(updateRowSet: IFactoryCalendarOverride[], DeleteRowset: any[]) {
    this.spinner = true;
    if (this.data.mode === dialogMode.create) {
      this.appData.post(this.appData.url.createCalendar, [], updateRowSet).subscribe((response) => {
        this.spinner = false;
        this.dialogRef.close('Created');
      }, (errResp) => {
        this.spinner = false;
        this.dialogRef.close(errResp.error.message);
      });
    } else {
      const services = DeleteRowset;
      services.push(this.appData.put(this.appData.url.updateCalendar, [], updateRowSet));
      Observable.forkJoin(services).subscribe(t => {
        this.spinner = false;
        t.indexOf(false) === -1 ? this.dialogRef.close('Updated') : this.dialogRef.close('Error');
      }, error => {
        this.spinner = false; this.dialogRef.close('Error');
      });
    }
  }

  public getDateStatus() {
    if (typeof this.formValues.PlantID !== 'undefined' && typeof this.formValues.OverrideDate !== 'undefined') {
      this.loading = true;
      this.appData.get(this.appData.url.getDateStatus, [this.formValues.PlantID, this.datePipe.transform(this.formValues.OverrideDate, 'yyyy-MM-dd')]).subscribe((response) => {
        this.holidayStatus = response.length > 0 ? response[0].WorkingDayIndc === 'Y' ? 'Working Day' : 'Holiday' : '';
        this.loading = false;
      });
    }
  }
}
