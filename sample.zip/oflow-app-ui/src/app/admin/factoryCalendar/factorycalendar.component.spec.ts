import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FactoryCalendarComponent } from './factorycalendar.component';

describe('HomeComponent', () => {
  let component: FactoryCalendarComponent;
  let fixture: ComponentFixture<FactoryCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FactoryCalendarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FactoryCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
