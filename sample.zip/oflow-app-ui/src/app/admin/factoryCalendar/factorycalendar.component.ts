import { Component, OnInit, ViewChild } from '@angular/core';
import { AppState } from '../../_services';
import { AppData } from '../../app.data';
import { NGXLogger } from 'ngx-logger';
import { MatDialog, MatDialogConfig, MatSort, MatPaginator, MatTableDataSource } from '@angular/material';
import { map, forEach, remove } from 'lodash';
import { DeleteDialogComponent } from '../../_shared/components/deletedialog/deletedialog.component';
import { CreateDialogComponent } from './createCalendarDialog/createdialog.component';
import { ToastrService } from 'ngx-toastr';
import { deleteDialogFlag, dialogMode, DialogContent } from '../../_shared/interface/dialogEnum';
import { Observable } from 'rxjs/Observable';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-factory-calendar',
  templateUrl: './factorycalendar.component.html',
  styleUrls: ['./factorycalendar.component.css'],
})

export class FactoryCalendarComponent implements OnInit {
  public columnList: string[];
  private currentYear = new Date().getFullYear();
  public dayIndicatorOptions: any = [
    { Code: 'null', Description: 'None' },
    { Code: 'H', Description: 'Holiday' },
    { Code: 'F', Description: 'Forced Workday' }
  ];
  public yearList = [
    { value: this.currentYear, viewValue: this.currentYear },
    { value: this.currentYear + 1, viewValue: this.currentYear + 1 },
    { value: this.currentYear + 2, viewValue: this.currentYear + 2 }
  ];
  public plant: any;
  public department: any;
  public loading: boolean = false;
  public dataSource: any;
  public deletedItems: any[] = [];
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private appState: AppState, private datePipe: DatePipe, private appData: AppData, private logger: NGXLogger, public dialog: MatDialog, private notification: ToastrService) { }

  ngOnInit() {
    this.getCalendarHistory();
    this.getPlant();
    this.getDepartment();
  }
  public getPlant() {
    this.appData.get(this.appData.url.getPlant, []).subscribe((plant_data) => {
      this.plant = plant_data;
    });
  }
  public getDepartment() {
    this.appData.get(this.appData.url.getDepartment, []).subscribe((dept_data) => {
      this.department = dept_data;
    });
  }

  public openCreateUpdateDialog(calendarMode, formData): void {
    const createDialogRef = this.dialog.open(CreateDialogComponent, {
      disableClose: true,
      width: DialogContent.widthMedium,
      data: {
        plant: this.plant,
        department: this.department,
        selectOption: this.dayIndicatorOptions,
        defaultPlantID: calendarMode === dialogMode.edit ? formData.PlantID : this.plant[0].PlantID,
        mode: calendarMode,
        editdata: formData
      }
    });

    createDialogRef.afterClosed().subscribe(record => {
      if (!record) { return; }
      if (record === dialogMode.Created || record === dialogMode.Updated) {
        this.notification.success(`Calendar ${record} Successfully`);
        this.getCalendarHistory();
      } else {
        this.notification.warning(record);
      }
    });
  }

  public getByYear(event) {
    this.getCalendarHistory(event.value);
  }

  public checkMulitDelete(event, PlantID, OverrideDate) {
    event.checked ? this.deletedItems.push({ PlantID: PlantID, OverrideDate: OverrideDate }) : remove(this.deletedItems, { PlantID: PlantID, OverrideDate: OverrideDate });
  }

  public openDeleteDialog(data, type): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = DialogContent.widthSmall;
    dialogConfig.data = {
      title: DialogContent.title,
      bodyMessage: DialogContent.desc,
      deleteItem: type === dialogMode.multiple ? data : `Plant ID : ${data.PlantID} - ${this.datePipe.transform(data.OverrideDate, 'MMM dd yyyy')}`,
      type: type
    };
    const deleteDialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    deleteDialogRef.afterClosed().subscribe(record => {
      if (!record) { return; }
      if (record === deleteDialogFlag.yes) {
        this.loading = true;
        type === dialogMode.single ? this.singleDelete(data) : this.multiDelete();
      }
    });
  }

  private singleDelete(data) {
    this.appData.delete(this.appData.url.deleteCalendar, [data.PlantID, data.OverrideDate]).subscribe((deleteresponse) => {
      this.notification.success('Deleted Successfully');
      this.getCalendarHistory();
    }, err => {
      this.loading = true;
      this.notification.error(err.error.message);
    });
  }

  private multiDelete() {
    const services = [];
    this.deletedItems.forEach(deleteItem => {
      services.push(this.appData.delete(this.appData.url.deleteCalendar, [deleteItem.PlantID, deleteItem.OverrideDate]));
    });
    Observable.forkJoin(services).subscribe(t => {
      this.notification.success('Deleted Successfully');
      this.deletedItems = [];
      this.getCalendarHistory();
    }, error => {
      this.loading = false;
      this.deletedItems = [];
      this.notification.error(error.error.message);
    });
  }

  public getCalendarHistory(calendarYear?) {
    calendarYear === undefined ? calendarYear = this.currentYear : calendarYear = calendarYear;
    this.loading = true;
    this.appData.get(this.appData.url.getCalendar, [calendarYear]).subscribe((calendardata) => {
      const columns = ['MultiDel', 'OverrideDate', 'PlantID'];
      forEach(calendardata[0], function (value, key) { if (columns.indexOf(key) === -1) { columns.push(key); } });
      columns.push('Action');
      this.columnList = columns;
      const ELEMENT_DATA = calendardata;
      this.dataSource = new MatTableDataSource(ELEMENT_DATA);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.loading = false;
    });
  }
}
